--
-- PostgreSQL database dump
--

\restrict yvyIUO0ttSvGAyeZLrl5fTYiT69hMoZQQdMknJchktpEPI9NfveESVx9AGQnciE

-- Dumped from database version 16.14 (Homebrew)
-- Dumped by pg_dump version 16.14 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: complainttype; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.complainttype AS ENUM (
    'QUALITY',
    'TIMELINESS',
    'COMMUNICATION',
    'BILLING',
    'SCOPE',
    'OTHER'
);


--
-- Name: referencetype; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.referencetype AS ENUM (
    'PROJECT',
    'AGREEMENT',
    'TOKEN',
    'DRN',
    'OTHER'
);


--
-- Name: severity; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.severity AS ENUM (
    'LOW',
    'MEDIUM',
    'HIGH',
    'CRITICAL'
);


--
-- Name: status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.status AS ENUM (
    'OPEN',
    'INVESTIGATING',
    'RESOLVED',
    'CLOSED',
    'REJECTED'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_log (
    id integer NOT NULL,
    user_id uuid,
    action character varying(100) NOT NULL,
    entity_type character varying(50) NOT NULL,
    entity_id uuid,
    before_json jsonb,
    after_json jsonb,
    ip_address inet,
    user_agent character varying(500),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.audit_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.audit_log_id_seq OWNED BY public.audit_log.id;


--
-- Name: boq_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.boq_items (
    id uuid NOT NULL,
    boq_id uuid NOT NULL,
    line_number integer NOT NULL,
    category character varying(100),
    description text NOT NULL,
    specification text,
    unit character varying(50) NOT NULL,
    quantity numeric(18,2) NOT NULL,
    rate numeric(18,2) NOT NULL,
    amount numeric(18,2) NOT NULL
);


--
-- Name: boqs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.boqs (
    id uuid NOT NULL,
    project_id uuid NOT NULL,
    version_number integer NOT NULL,
    file_name character varying(255) NOT NULL,
    file_path character varying(500) NOT NULL,
    parsed_by uuid,
    parsed_at timestamp with time zone DEFAULT now() NOT NULL,
    notes text,
    is_active boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: checklist_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.checklist_items (
    id uuid NOT NULL,
    checklist_id uuid NOT NULL,
    description text NOT NULL,
    category character varying(100),
    is_mandatory boolean NOT NULL,
    is_completed boolean NOT NULL,
    completed_by uuid,
    completed_at timestamp with time zone,
    evidence_document_id uuid
);


--
-- Name: client_complaints; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_complaints (
    id uuid NOT NULL,
    complaint_id character varying(64) NOT NULL,
    date_raised date NOT NULL,
    client_id uuid NOT NULL,
    reference_type public.referencetype NOT NULL,
    reference_id character varying(64),
    complaint_type public.complainttype NOT NULL,
    severity public.severity NOT NULL,
    description text,
    root_cause text,
    status public.status NOT NULL,
    owner_id uuid,
    closure_date date,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: client_feedbacks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.client_feedbacks (
    id uuid NOT NULL,
    feedback_id character varying(64) NOT NULL,
    date date NOT NULL,
    client_id uuid NOT NULL,
    reference_type character varying(50) NOT NULL,
    reference_id character varying(64),
    overall_rating integer NOT NULL,
    quality_rating integer NOT NULL,
    timeliness_rating integer NOT NULL,
    communication_rating integer NOT NULL,
    would_recommend boolean NOT NULL,
    comments text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: clients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clients (
    id uuid NOT NULL,
    name character varying(255) NOT NULL,
    code character varying(50) NOT NULL,
    address text,
    city character varying(100),
    state character varying(100),
    pincode character varying(20),
    country character varying(100) NOT NULL,
    gst_number character varying(50),
    primary_email character varying(320) NOT NULL,
    primary_phone character varying(50),
    notes text,
    is_active boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    business_id character varying(64),
    industry character varying(120),
    date_onboarded date,
    client_status character varying(32) DEFAULT 'Active'::character varying NOT NULL,
    first_lead_id character varying(64),
    first_inquiry_id character varying(64)
);


--
-- Name: compliance_checklist_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.compliance_checklist_items (
    id uuid NOT NULL,
    standard_id uuid NOT NULL,
    category character varying(100) NOT NULL,
    requirement character varying(500) NOT NULL,
    description text,
    is_mandatory boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: compliance_checklists; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.compliance_checklists (
    id uuid NOT NULL,
    project_id uuid NOT NULL,
    template_id uuid NOT NULL,
    status character varying(50) NOT NULL,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: compliance_standards; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.compliance_standards (
    id uuid NOT NULL,
    name character varying(50) NOT NULL,
    version character varying(50) NOT NULL,
    description text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: compliance_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.compliance_templates (
    id uuid NOT NULL,
    name character varying(255) NOT NULL,
    standard_code character varying(50) NOT NULL,
    category character varying(100),
    is_active boolean NOT NULL,
    items text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: contacts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contacts (
    id uuid NOT NULL,
    client_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(320) NOT NULL,
    phone character varying(50),
    designation character varying(100),
    is_primary boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: document_folders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_folders (
    id uuid NOT NULL,
    project_id uuid NOT NULL,
    parent_id uuid,
    name character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: document_references; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_references (
    id uuid NOT NULL,
    drn character varying(30) NOT NULL,
    project_id uuid NOT NULL,
    token_id uuid,
    document_type character varying(100) NOT NULL,
    document_name character varying(255) NOT NULL,
    document_reference character varying(255),
    document_date date,
    uploaded_by character varying(255),
    access_level character varying(20),
    description text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.documents (
    id uuid NOT NULL,
    project_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    original_name character varying(255) NOT NULL,
    file_path character varying(500) NOT NULL,
    category character varying(50) NOT NULL,
    version integer NOT NULL,
    previous_version_id uuid,
    size_bytes integer,
    mime_type character varying(100),
    uploaded_by uuid,
    uploaded_at timestamp with time zone DEFAULT now() NOT NULL,
    is_deleted boolean NOT NULL
);


--
-- Name: drn; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.drn (
    id uuid NOT NULL,
    drn_code character varying(64) NOT NULL,
    doc_type character varying(50) NOT NULL,
    date timestamp with time zone NOT NULL,
    associated_project_id uuid,
    associated_token_id uuid,
    author_id uuid,
    document_nature character varying(50) NOT NULL,
    intended_user character varying(50) NOT NULL,
    description character varying(1000) NOT NULL,
    revision character varying(10) NOT NULL,
    status character varying(50) NOT NULL,
    remarks character varying(500),
    file_path character varying(500),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    is_deleted boolean DEFAULT false NOT NULL
);


--
-- Name: id_sequence; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.id_sequence (
    type_code character varying(16) NOT NULL,
    year integer NOT NULL,
    last_value integer DEFAULT 0 NOT NULL
);


--
-- Name: inquiries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inquiries (
    id uuid NOT NULL,
    inquiry_id character varying(32) NOT NULL,
    inquiry_date date NOT NULL,
    inquiry_type character varying(32) NOT NULL,
    inquiry_source character varying(100),
    client_name character varying(255) NOT NULL,
    requirement_summary text,
    estimated_value numeric(18,2),
    priority character varying(16) NOT NULL,
    status character varying(16) NOT NULL,
    owner uuid,
    technical_lead uuid,
    notes text,
    converted_to_client_id uuid,
    converted_to_agreement_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: instagram_metrics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.instagram_metrics (
    id uuid NOT NULL,
    metric_id character varying(64) NOT NULL,
    period_yyyymm character varying(6) NOT NULL,
    followers_start integer NOT NULL,
    followers_end integer NOT NULL,
    followers_net_add integer NOT NULL,
    impressions integer NOT NULL,
    reach integer NOT NULL,
    profile_visits integer NOT NULL,
    likes integer NOT NULL,
    comments integer NOT NULL,
    shares integer NOT NULL,
    saves integer NOT NULL,
    engagement_rate numeric(5,4) NOT NULL,
    posts_count integer NOT NULL,
    reels_count integer NOT NULL,
    stories_count integer NOT NULL,
    website_clicks integer NOT NULL,
    inbound_dms integer NOT NULL,
    leads_count integer NOT NULL,
    inquiry_count integer NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: invoice_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoice_items (
    id uuid NOT NULL,
    invoice_id uuid NOT NULL,
    description text NOT NULL,
    quantity numeric(10,2) NOT NULL,
    rate numeric(18,2) NOT NULL,
    amount numeric(18,2) NOT NULL,
    category character varying(50),
    time_entry_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: invoices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoices (
    id uuid NOT NULL,
    project_id uuid NOT NULL,
    invoice_number character varying(50) NOT NULL,
    status character varying(20) NOT NULL,
    subtotal numeric(18,2) NOT NULL,
    tax_rate numeric(5,2) NOT NULL,
    tax_amount numeric(18,2) NOT NULL,
    total numeric(18,2) NOT NULL,
    currency character varying(3) NOT NULL,
    due_date date,
    notes text,
    created_by uuid,
    paid_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: linkedin_metrics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.linkedin_metrics (
    id uuid NOT NULL,
    metric_id character varying(64) NOT NULL,
    period_yyyymm character varying(6) NOT NULL,
    followers_start integer NOT NULL,
    followers_end integer NOT NULL,
    followers_net_add integer NOT NULL,
    impressions integer NOT NULL,
    reach integer NOT NULL,
    profile_views integer NOT NULL,
    reactions integer NOT NULL,
    comments integer NOT NULL,
    reposts integer NOT NULL,
    engagement_rate numeric(5,4) NOT NULL,
    posts_count integer NOT NULL,
    articles_count integer NOT NULL,
    videos_count integer NOT NULL,
    website_clicks integer NOT NULL,
    inbound_dms integer NOT NULL,
    leads_count integer NOT NULL,
    inquiry_count integer NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: material_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.material_categories (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text
);


--
-- Name: material_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.material_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: material_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.material_categories_id_seq OWNED BY public.material_categories.id;


--
-- Name: materials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.materials (
    id uuid NOT NULL,
    name character varying(255) NOT NULL,
    code character varying(50) NOT NULL,
    description text,
    category_id integer,
    unit_id integer,
    specification text,
    default_lead_time_days integer,
    is_active boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    type character varying(64) NOT NULL,
    title character varying(255) NOT NULL,
    message text NOT NULL,
    reference_type character varying(50),
    reference_id uuid,
    is_read boolean,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: project_compliance_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_compliance_items (
    id uuid NOT NULL,
    project_id uuid NOT NULL,
    checklist_item_id uuid NOT NULL,
    status character varying(20) NOT NULL,
    evidence_document_id uuid,
    notes text,
    reviewed_by uuid,
    reviewed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: project_costs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_costs (
    id uuid NOT NULL,
    project_id uuid NOT NULL,
    category character varying(50) NOT NULL,
    description text NOT NULL,
    amount numeric(18,2) NOT NULL,
    quantity numeric(10,2),
    rate numeric(18,2),
    reference_id uuid,
    reference_type character varying(50),
    date date NOT NULL,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: projects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.projects (
    id uuid NOT NULL,
    client_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    code character varying(50) NOT NULL,
    description text,
    status character varying(50) NOT NULL,
    pm_id uuid,
    designer_id uuid,
    auditor_id uuid,
    location character varying(255),
    estimated_value numeric(18,2),
    actual_value numeric(18,2),
    start_date date,
    target_end_date date,
    actual_end_date date,
    is_active boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    business_id character varying(64),
    milestone character varying(50),
    progress_indicators jsonb,
    status_updates text,
    team_leader_id uuid,
    project_owner_id uuid,
    notes text
);


--
-- Name: quote_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.quote_items (
    id uuid NOT NULL,
    quote_id uuid NOT NULL,
    boq_item_id uuid,
    line_number integer NOT NULL,
    category character varying(100),
    description text NOT NULL,
    specification text,
    unit character varying(50) NOT NULL,
    quantity numeric(18,2) NOT NULL,
    rate numeric(18,2) NOT NULL,
    amount numeric(18,2) NOT NULL
);


--
-- Name: quotes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.quotes (
    id uuid NOT NULL,
    project_id uuid NOT NULL,
    boq_id uuid NOT NULL,
    version_number integer NOT NULL,
    status character varying(50) NOT NULL,
    subtotal numeric(18,2) NOT NULL,
    markup_percent numeric(5,2) NOT NULL,
    markup_amount numeric(18,2) NOT NULL,
    tax_percent numeric(5,2) NOT NULL,
    tax_amount numeric(18,2) NOT NULL,
    total_amount numeric(18,2) NOT NULL,
    terms text,
    validity_days integer NOT NULL,
    valid_until date,
    created_by uuid,
    approved_by uuid,
    approved_at timestamp with time zone,
    sent_at timestamp with time zone,
    client_response character varying(50),
    client_response_at timestamp with time zone,
    client_response_notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: reference_counters; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reference_counters (
    id uuid NOT NULL,
    entity_type character varying(10) NOT NULL,
    year integer NOT NULL,
    last_seq integer NOT NULL
);


--
-- Name: refresh_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.refresh_tokens (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    token_hash character varying(255) NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone
);


--
-- Name: research_collaborations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.research_collaborations (
    id uuid NOT NULL,
    collab_id character varying(64) NOT NULL,
    institution_name character varying(255) NOT NULL,
    institution_type character varying(32) NOT NULL,
    department_or_lab character varying(255),
    faculty_or_pi_name character varying(255),
    collab_type character varying(32) NOT NULL,
    collab_objective text,
    domain character varying(32) NOT NULL,
    start_date date,
    end_date date,
    collab_status character varying(16) NOT NULL,
    engagement_model character varying(32) NOT NULL,
    linked_innovation_id character varying(64),
    linked_project_id character varying(64),
    primary_internal_owner_id uuid,
    secondary_internal_owner_id uuid,
    expected_output character varying(32) NOT NULL,
    actual_output text,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: research_innovations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.research_innovations (
    id uuid NOT NULL,
    innovation_id character varying(64) NOT NULL,
    innovation_title character varying(255) NOT NULL,
    innovation_type character varying(32) NOT NULL,
    domain character varying(32) NOT NULL,
    problem_statement text,
    innovation_trigger character varying(32),
    start_date date,
    concept_freeze_date date,
    validation_complete_date date,
    rollout_date date,
    time_to_market_days integer,
    innovation_status character varying(32) NOT NULL,
    commercialization_status character varying(32),
    linked_project_id character varying(64),
    linked_client_id character varying(64),
    primary_owner_id uuid,
    secondary_owner_id uuid,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: rfq_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rfq_items (
    id uuid NOT NULL,
    rfq_id uuid NOT NULL,
    material_id uuid,
    boq_item_id uuid,
    description character varying(500) NOT NULL,
    unit character varying(50) NOT NULL,
    quantity numeric(18,2) NOT NULL,
    target_rate numeric(18,2),
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: rfq_responses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rfq_responses (
    id uuid NOT NULL,
    rfq_id uuid NOT NULL,
    vendor_id uuid NOT NULL,
    status character varying(50) NOT NULL,
    unit_price numeric(18,2),
    total_price numeric(18,2),
    delivery_days numeric(10,0),
    validity_days numeric(10,0),
    notes text,
    submitted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: rfqs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rfqs (
    id uuid NOT NULL,
    project_id uuid NOT NULL,
    quote_id uuid,
    title character varying(255) NOT NULL,
    status character varying(50) NOT NULL,
    submission_deadline date,
    notes text,
    created_by uuid,
    awarded_to_vendor_id uuid,
    sent_at timestamp with time zone,
    closed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: service_agreements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.service_agreements (
    id uuid NOT NULL,
    agreement_id character varying(32) NOT NULL,
    client_id uuid NOT NULL,
    inquiry_id uuid,
    service_name character varying(255) NOT NULL,
    start_date date NOT NULL,
    end_date date,
    total_tokens numeric(10,2),
    billing_model character varying(32) NOT NULL,
    status character varying(16) NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: sustainability_metrics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sustainability_metrics (
    id uuid NOT NULL,
    reference_id character varying(64) NOT NULL,
    reference_kind character varying(50) NOT NULL,
    compliant_with_green_standards character varying(255),
    total_energy_saved_kwh numeric(14,2),
    co2_emissions_avoided_tco2e numeric(14,4),
    lifecycle_cost_savings_inr numeric(18,2),
    insulation_efficiency_actual_over_expected numeric(5,3),
    insulation_efficiency_status character varying(50) NOT NULL,
    payback_period_months numeric(10,0),
    measured_at date NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: task_comments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.task_comments (
    id uuid NOT NULL,
    task_id uuid NOT NULL,
    author_id uuid NOT NULL,
    parent_comment_id uuid,
    content text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone
);


--
-- Name: task_dependencies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.task_dependencies (
    id uuid NOT NULL,
    task_id uuid NOT NULL,
    depends_on_task_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: tasks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tasks (
    id uuid NOT NULL,
    project_id uuid NOT NULL,
    parent_id uuid,
    title character varying(200) NOT NULL,
    description text,
    status character varying(20) NOT NULL,
    priority character varying(20) NOT NULL,
    assignee_id uuid,
    created_by uuid NOT NULL,
    due_date date,
    estimated_hours numeric(6,2),
    actual_hours numeric(6,2),
    boq_item_id uuid,
    is_deleted boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: time_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.time_entries (
    id uuid NOT NULL,
    project_id uuid NOT NULL,
    task_id uuid,
    user_id uuid NOT NULL,
    date date NOT NULL,
    hours numeric(4,2) NOT NULL,
    description text NOT NULL,
    is_billable boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: time_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.time_log (
    id uuid NOT NULL,
    log_date date NOT NULL,
    employee_id uuid NOT NULL,
    employee_role_at_log character varying(16) NOT NULL,
    work_type character varying(16) NOT NULL,
    reference_id character varying(255) NOT NULL,
    reference_kind character varying(16) NOT NULL,
    revision boolean NOT NULL,
    project_name character varying(255) NOT NULL,
    activity_type character varying(16) NOT NULL,
    software_used character varying(64) NOT NULL,
    work_mode character varying(32) NOT NULL,
    hours_logged numeric(5,2) NOT NULL,
    billable_hours numeric(5,2) NOT NULL,
    remarks text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: timesheet_audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.timesheet_audit_log (
    id uuid NOT NULL,
    timesheet_id uuid NOT NULL,
    action character varying(50) NOT NULL,
    performed_by uuid NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: timesheets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.timesheets (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    week_start date NOT NULL,
    week_end date NOT NULL,
    status character varying(20) NOT NULL,
    total_hours numeric(6,2) NOT NULL,
    billable_hours numeric(6,2) NOT NULL,
    approved_by uuid,
    approved_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tokens (
    id uuid NOT NULL,
    token_id character varying(32) NOT NULL,
    token_date date NOT NULL,
    agreement_id uuid NOT NULL,
    token_type character varying(32) NOT NULL,
    description text,
    token_status character varying(32) NOT NULL,
    tokens_used numeric(8,2),
    swa_team_lead uuid,
    project_owner uuid,
    client_employee_name character varying(255),
    client_employee_email character varying(320),
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: units_of_measure; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.units_of_measure (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    abbreviation character varying(20) NOT NULL
);


--
-- Name: units_of_measure_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.units_of_measure_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: units_of_measure_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.units_of_measure_id_seq OWNED BY public.units_of_measure.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    email character varying(320) NOT NULL,
    password_hash character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    role character varying(50) NOT NULL,
    is_active boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    version integer NOT NULL,
    employee_business_id character varying(64),
    employee_role_code character varying(16),
    department character varying(64),
    date_of_joining date,
    date_of_exit date,
    employment_status character varying(20) DEFAULT 'Active'::character varying NOT NULL,
    location character varying(128),
    reporting_manager_id uuid
);


--
-- Name: vendor_contacts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vendor_contacts (
    id uuid NOT NULL,
    vendor_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    designation character varying(100),
    email character varying(255),
    phone character varying(20),
    is_primary boolean NOT NULL
);


--
-- Name: vendor_material_prices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vendor_material_prices (
    id uuid NOT NULL,
    vendor_id uuid NOT NULL,
    material_id uuid NOT NULL,
    price numeric(18,2) NOT NULL,
    moq integer NOT NULL,
    lead_time_days integer,
    valid_until timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: vendors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vendors (
    id uuid NOT NULL,
    name character varying(255) NOT NULL,
    code character varying(50) NOT NULL,
    address text,
    city character varying(100),
    state character varying(100),
    pincode character varying(20),
    country character varying(100) NOT NULL,
    gst_number character varying(50),
    primary_email character varying(320) NOT NULL,
    primary_phone character varying(50),
    rating integer,
    notes text,
    is_active boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: website_metrics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.website_metrics (
    id uuid NOT NULL,
    metric_id character varying(64) NOT NULL,
    period_yyyymm character varying(6) NOT NULL,
    sessions integer NOT NULL,
    users integer NOT NULL,
    new_users integer NOT NULL,
    returning_users integer NOT NULL,
    page_views integer NOT NULL,
    pages_per_session double precision NOT NULL,
    avg_session_duration_sec integer NOT NULL,
    bounce_rate double precision NOT NULL,
    direct_traffic_pct double precision NOT NULL,
    organic_traffic_pct double precision NOT NULL,
    social_traffic_pct double precision NOT NULL,
    referral_traffic_pct double precision NOT NULL,
    paid_traffic_pct double precision NOT NULL,
    contact_form_submissions integer NOT NULL,
    consultation_requests integer NOT NULL,
    downloads_count integer NOT NULL,
    call_clicks integer NOT NULL,
    leads_count integer NOT NULL,
    inquiry_count integer NOT NULL,
    projects_converted integer NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: audit_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log ALTER COLUMN id SET DEFAULT nextval('public.audit_log_id_seq'::regclass);


--
-- Name: material_categories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.material_categories ALTER COLUMN id SET DEFAULT nextval('public.material_categories_id_seq'::regclass);


--
-- Name: units_of_measure id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.units_of_measure ALTER COLUMN id SET DEFAULT nextval('public.units_of_measure_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alembic_version (version_num) FROM stdin;
0014_project_tracking
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_log (id, user_id, action, entity_type, entity_id, before_json, after_json, ip_address, user_agent, created_at) FROM stdin;
4	\N	auth.login_fail	auth	\N	null	null	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	2026-05-19 23:51:31.731512+05:30
2	\N	auth.login_fail	auth	\N	null	null	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	2026-05-19 23:51:31.731171+05:30
42	\N	auth.login_fail	auth	\N	null	null	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	2026-05-20 14:53:20.373615+05:30
44	604daaee-2407-43c2-a1b2-049b758d661a	auth.login_success	auth	\N	null	null	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	2026-05-20 14:53:32.696662+05:30
46	604daaee-2407-43c2-a1b2-049b758d661a	auth.login_success	auth	\N	null	null	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	2026-05-20 14:54:13.155635+05:30
49	604daaee-2407-43c2-a1b2-049b758d661a	auth.login_success	auth	\N	null	null	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	2026-05-20 14:55:33.650879+05:30
50	8e0c17cd-5487-416f-b795-caaf6d8e8a13	auth.login_success	auth	\N	null	null	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	2026-05-20 14:55:33.655383+05:30
52	604daaee-2407-43c2-a1b2-049b758d661a	auth.logout	auth	\N	null	null	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	2026-05-20 14:55:36.498238+05:30
67	604daaee-2407-43c2-a1b2-049b758d661a	auth.login_success	auth	\N	null	null	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	2026-05-20 17:06:04.046318+05:30
71	604daaee-2407-43c2-a1b2-049b758d661a	auth.logout	auth	\N	null	null	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	2026-05-20 17:06:04.870345+05:30
73	604daaee-2407-43c2-a1b2-049b758d661a	auth.token_refresh	auth	\N	null	null	\N	\N	2026-05-20 18:24:55.170394+05:30
74	604daaee-2407-43c2-a1b2-049b758d661a	auth.token_refresh	auth	\N	null	null	\N	\N	2026-05-20 19:51:46.465969+05:30
76	8e0c17cd-5487-416f-b795-caaf6d8e8a13	auth.login_success	auth	\N	null	null	127.0.0.1	python-httpx/0.28.1	2026-05-21 15:59:30.158691+05:30
78	604daaee-2407-43c2-a1b2-049b758d661a	auth.login_success	auth	\N	null	null	127.0.0.1	curl/8.7.1	2026-05-21 18:23:56.423834+05:30
79	604daaee-2407-43c2-a1b2-049b758d661a	auth.login_success	auth	\N	null	null	127.0.0.1	curl/8.7.1	2026-05-21 18:24:13.163235+05:30
82	604daaee-2407-43c2-a1b2-049b758d661a	auth.login_success	auth	\N	null	null	127.0.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/148.0.7778.96 Safari/537.36	2026-05-21 18:30:05.458374+05:30
86	\N	auth.login_fail	auth	\N	null	null	127.0.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Cursor/3.4.20 Chrome/142.0.7444.265 Electron/39.8.1 Safari/537.36	2026-05-22 11:28:28.914502+05:30
87	604daaee-2407-43c2-a1b2-049b758d661a	auth.token_refresh	auth	\N	null	null	\N	\N	2026-05-22 11:28:29.362122+05:30
88	\N	auth.login_fail	auth	\N	null	null	127.0.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Cursor/3.4.20 Chrome/142.0.7444.265 Electron/39.8.1 Safari/537.36	2026-05-22 11:28:54.665924+05:30
1	\N	auth.login_fail	auth	\N	null	null	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	2026-05-19 23:51:31.731392+05:30
43	8e0c17cd-5487-416f-b795-caaf6d8e8a13	auth.login_success	auth	\N	null	null	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	2026-05-20 14:53:32.693118+05:30
45	604daaee-2407-43c2-a1b2-049b758d661a	auth.login_success	auth	\N	null	null	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	2026-05-20 14:53:42.86813+05:30
47	\N	auth.login_fail	auth	\N	null	null	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	2026-05-20 14:55:31.339589+05:30
48	604daaee-2407-43c2-a1b2-049b758d661a	auth.login_success	auth	\N	null	null	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	2026-05-20 14:55:33.611683+05:30
51	604daaee-2407-43c2-a1b2-049b758d661a	auth.login_success	auth	\N	null	null	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	2026-05-20 14:55:35.54438+05:30
53	604daaee-2407-43c2-a1b2-049b758d661a	auth.login_success	auth	\N	null	null	127.0.0.1	curl/8.7.1	2026-05-20 16:59:55.970473+05:30
54	604daaee-2407-43c2-a1b2-049b758d661a	auth.login_success	auth	\N	null	null	127.0.0.1	curl/8.7.1	2026-05-20 17:00:02.893277+05:30
55	604daaee-2407-43c2-a1b2-049b758d661a	auth.login_success	auth	\N	null	null	127.0.0.1	curl/8.7.1	2026-05-20 17:00:13.391133+05:30
56	604daaee-2407-43c2-a1b2-049b758d661a	auth.login_success	auth	\N	null	null	127.0.0.1	python-requests/2.34.2	2026-05-20 17:04:59.32196+05:30
57	8e0c17cd-5487-416f-b795-caaf6d8e8a13	auth.login_success	auth	\N	null	null	127.0.0.1	python-requests/2.34.2	2026-05-20 17:04:59.65306+05:30
58	b3ccbe51-aa77-48d9-9ee0-d9638f5c38c9	auth.login_success	auth	\N	null	null	127.0.0.1	python-requests/2.34.2	2026-05-20 17:04:59.963658+05:30
59	0a3b4428-bb3c-439b-a1a6-1f9e82f3defa	auth.login_success	auth	\N	null	null	127.0.0.1	python-requests/2.34.2	2026-05-20 17:05:00.357398+05:30
60	3ba9a171-6f96-4e11-9b35-f5ce4924a1d7	auth.login_success	auth	\N	null	null	127.0.0.1	python-requests/2.34.2	2026-05-20 17:05:00.743906+05:30
61	8e0c17cd-5487-416f-b795-caaf6d8e8a13	project.transition	project	2217b8e4-571e-4e71-b22d-956b401cdc7e	{"status": "Lead"}	{"status": "Quote"}	\N	\N	2026-05-20 17:05:00.952688+05:30
62	604daaee-2407-43c2-a1b2-049b758d661a	client.create	client	bc2188d6-8323-4466-a495-163470623339	null	{"id": "bc2188d6-8323-4466-a495-163470623339", "code": "DEMO-999", "name": "Demo Client", "primary_email": "demo@example.com"}	\N	\N	2026-05-20 17:05:01.005244+05:30
63	604daaee-2407-43c2-a1b2-049b758d661a	client.delete	client	bc2188d6-8323-4466-a495-163470623339	{"deleted_at": null}	{"deleted_at": "2026-05-20 11:35:01.012756+05:30"}	\N	\N	2026-05-20 17:05:01.015221+05:30
64	604daaee-2407-43c2-a1b2-049b758d661a	project.create	project	25de626c-ccf7-482e-bd00-6ab5a8f403f9	null	{"id": "25de626c-ccf7-482e-bd00-6ab5a8f403f9", "code": "DEL-999", "name": "Delete Me", "pm_id": null, "status": "Lead", "location": null, "client_id": "41c2e397-2cf6-4a8d-9cd2-9db1f779f172", "is_active": true, "auditor_id": null, "start_date": null, "description": null, "designer_id": null, "actual_value": null, "actual_end_date": null, "estimated_value": null, "target_end_date": null}	\N	\N	2026-05-20 17:05:01.033593+05:30
65	604daaee-2407-43c2-a1b2-049b758d661a	project.delete	project	25de626c-ccf7-482e-bd00-6ab5a8f403f9	{"id": "25de626c-ccf7-482e-bd00-6ab5a8f403f9", "code": "DEL-999", "name": "Delete Me", "pm_id": null, "status": "Lead", "location": null, "client_id": "41c2e397-2cf6-4a8d-9cd2-9db1f779f172", "is_active": true, "auditor_id": null, "start_date": null, "description": null, "designer_id": null, "actual_value": null, "actual_end_date": null, "estimated_value": null, "target_end_date": null}	null	\N	\N	2026-05-20 17:05:01.042502+05:30
66	\N	auth.login_fail	auth	\N	null	null	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	2026-05-20 17:06:03.474271+05:30
68	604daaee-2407-43c2-a1b2-049b758d661a	auth.login_success	auth	\N	null	null	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	2026-05-20 17:06:04.092869+05:30
69	8e0c17cd-5487-416f-b795-caaf6d8e8a13	auth.login_success	auth	\N	null	null	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	2026-05-20 17:06:04.121388+05:30
70	604daaee-2407-43c2-a1b2-049b758d661a	auth.login_success	auth	\N	null	null	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	2026-05-20 17:06:04.652494+05:30
72	604daaee-2407-43c2-a1b2-049b758d661a	auth.login_success	auth	\N	null	null	127.0.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Cursor/3.4.20 Chrome/142.0.7444.265 Electron/39.8.1 Safari/537.36	2026-05-20 17:11:38.393622+05:30
75	604daaee-2407-43c2-a1b2-049b758d661a	auth.token_refresh	auth	\N	null	null	\N	\N	2026-05-21 15:40:30.035543+05:30
77	604daaee-2407-43c2-a1b2-049b758d661a	auth.login_success	auth	\N	null	null	127.0.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Cursor/3.4.20 Chrome/142.0.7444.265 Electron/39.8.1 Safari/537.36	2026-05-21 17:58:03.806798+05:30
80	604daaee-2407-43c2-a1b2-049b758d661a	auth.login_success	auth	\N	null	null	127.0.0.1	curl/8.7.1	2026-05-21 18:26:38.038375+05:30
81	604daaee-2407-43c2-a1b2-049b758d661a	auth.login_success	auth	\N	null	null	127.0.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/148.0.7778.96 Safari/537.36	2026-05-21 18:28:29.475948+05:30
83	604daaee-2407-43c2-a1b2-049b758d661a	auth.login_success	auth	\N	null	null	127.0.0.1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/148.0.7778.96 Safari/537.36	2026-05-21 18:31:55.601368+05:30
84	604daaee-2407-43c2-a1b2-049b758d661a	auth.token_refresh	auth	\N	null	null	\N	\N	2026-05-22 02:24:13.820722+05:30
85	604daaee-2407-43c2-a1b2-049b758d661a	auth.token_refresh	auth	\N	null	null	\N	\N	2026-05-22 11:01:21.440386+05:30
89	604daaee-2407-43c2-a1b2-049b758d661a	auth.login_success	auth	\N	null	null	127.0.0.1	python-httpx/0.27.0	2026-05-22 13:42:41.00897+05:30
90	8e0c17cd-5487-416f-b795-caaf6d8e8a13	auth.login_success	auth	\N	null	null	127.0.0.1	python-httpx/0.28.1	2026-07-04 16:04:36.584568+05:30
91	3ba9a171-6f96-4e11-9b35-f5ce4924a1d7	auth.login_success	auth	\N	null	null	127.0.0.1	python-httpx/0.28.1	2026-07-04 16:04:36.891143+05:30
92	8e0c17cd-5487-416f-b795-caaf6d8e8a13	auth.login_success	auth	\N	null	null	127.0.0.1	python-httpx/0.28.1	2026-07-04 16:04:38.212075+05:30
93	b3ccbe51-aa77-48d9-9ee0-d9638f5c38c9	auth.login_success	auth	\N	null	null	127.0.0.1	python-httpx/0.28.1	2026-07-04 16:04:38.457681+05:30
3	\N	auth.login_fail	auth	\N	null	null	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	2026-05-19 23:51:31.731272+05:30
5	\N	auth.login_fail	auth	\N	null	null	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	2026-05-19 23:54:03.425587+05:30
6	8e0c17cd-5487-416f-b795-caaf6d8e8a13	auth.login_success	auth	\N	null	null	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	2026-05-19 23:54:04.06839+05:30
8	604daaee-2407-43c2-a1b2-049b758d661a	auth.login_success	auth	\N	null	null	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	2026-05-19 23:54:04.068037+05:30
7	604daaee-2407-43c2-a1b2-049b758d661a	auth.login_success	auth	\N	null	null	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	2026-05-19 23:54:04.069704+05:30
9	604daaee-2407-43c2-a1b2-049b758d661a	auth.logout	auth	\N	null	null	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	2026-05-19 23:54:04.679828+05:30
10	604daaee-2407-43c2-a1b2-049b758d661a	auth.login_success	auth	\N	null	null	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	2026-05-19 23:55:53.689607+05:30
11	8e0c17cd-5487-416f-b795-caaf6d8e8a13	auth.login_success	auth	\N	null	null	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	2026-05-19 23:56:18.999311+05:30
12	\N	auth.login_fail	auth	\N	null	null	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	2026-05-19 23:57:58.415163+05:30
13	604daaee-2407-43c2-a1b2-049b758d661a	auth.login_success	auth	\N	null	null	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	2026-05-19 23:57:58.79194+05:30
14	604daaee-2407-43c2-a1b2-049b758d661a	auth.login_success	auth	\N	null	null	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	2026-05-19 23:57:58.792628+05:30
15	8e0c17cd-5487-416f-b795-caaf6d8e8a13	auth.login_success	auth	\N	null	null	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	2026-05-19 23:57:58.795446+05:30
16	604daaee-2407-43c2-a1b2-049b758d661a	auth.logout	auth	\N	null	null	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	2026-05-19 23:57:59.096173+05:30
17	\N	auth.login_fail	auth	\N	null	null	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	2026-05-19 23:58:38.706241+05:30
18	604daaee-2407-43c2-a1b2-049b758d661a	auth.login_success	auth	\N	null	null	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	2026-05-19 23:58:39.080591+05:30
19	8e0c17cd-5487-416f-b795-caaf6d8e8a13	auth.login_success	auth	\N	null	null	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	2026-05-19 23:58:39.081241+05:30
20	604daaee-2407-43c2-a1b2-049b758d661a	auth.login_success	auth	\N	null	null	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	2026-05-19 23:58:39.081587+05:30
21	604daaee-2407-43c2-a1b2-049b758d661a	auth.logout	auth	\N	null	null	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	2026-05-19 23:58:39.349932+05:30
22	\N	auth.login_fail	auth	\N	null	null	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	2026-05-20 14:43:05.255868+05:30
23	\N	auth.login_fail	auth	\N	null	null	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	2026-05-20 14:43:05.518944+05:30
24	8e0c17cd-5487-416f-b795-caaf6d8e8a13	auth.login_success	auth	\N	null	null	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	2026-05-20 14:43:08.408791+05:30
25	604daaee-2407-43c2-a1b2-049b758d661a	auth.login_success	auth	\N	null	null	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	2026-05-20 14:43:08.410066+05:30
26	604daaee-2407-43c2-a1b2-049b758d661a	auth.login_success	auth	\N	null	null	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	2026-05-20 14:43:08.449749+05:30
27	604daaee-2407-43c2-a1b2-049b758d661a	auth.login_success	auth	\N	null	null	127.0.0.1	curl/8.7.1	2026-05-20 14:43:29.64681+05:30
28	604daaee-2407-43c2-a1b2-049b758d661a	auth.login_success	auth	\N	null	null	127.0.0.1	curl/8.7.1	2026-05-20 14:43:36.245158+05:30
29	\N	auth.login_fail	auth	\N	null	null	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	2026-05-20 14:46:04.993772+05:30
30	\N	auth.login_fail	auth	\N	null	null	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	2026-05-20 14:46:04.997263+05:30
32	8e0c17cd-5487-416f-b795-caaf6d8e8a13	auth.login_success	auth	\N	null	null	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	2026-05-20 14:46:09.265375+05:30
33	604daaee-2407-43c2-a1b2-049b758d661a	auth.login_success	auth	\N	null	null	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	2026-05-20 14:46:09.28102+05:30
31	604daaee-2407-43c2-a1b2-049b758d661a	auth.login_success	auth	\N	null	null	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	2026-05-20 14:46:09.264574+05:30
34	604daaee-2407-43c2-a1b2-049b758d661a	auth.logout	auth	\N	null	null	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	2026-05-20 14:46:10.31368+05:30
35	\N	auth.login_fail	auth	\N	null	null	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	2026-05-20 14:47:02.190636+05:30
36	604daaee-2407-43c2-a1b2-049b758d661a	auth.login_success	auth	\N	null	null	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	2026-05-20 14:47:12.943836+05:30
37	8e0c17cd-5487-416f-b795-caaf6d8e8a13	auth.login_success	auth	\N	null	null	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	2026-05-20 14:47:13.301494+05:30
38	604daaee-2407-43c2-a1b2-049b758d661a	auth.login_success	auth	\N	null	null	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	2026-05-20 14:47:13.565326+05:30
39	604daaee-2407-43c2-a1b2-049b758d661a	auth.login_success	auth	\N	null	null	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	2026-05-20 14:49:45.148894+05:30
40	604daaee-2407-43c2-a1b2-049b758d661a	auth.login_success	auth	\N	null	null	127.0.0.1	curl/8.7.1	2026-05-20 14:52:19.11173+05:30
41	\N	auth.login_fail	auth	\N	null	null	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7778.96 Safari/537.36	2026-05-20 14:53:22.355758+05:30
\.


--
-- Data for Name: boq_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.boq_items (id, boq_id, line_number, category, description, specification, unit, quantity, rate, amount) FROM stdin;
\.


--
-- Data for Name: boqs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.boqs (id, project_id, version_number, file_name, file_path, parsed_by, parsed_at, notes, is_active, created_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: checklist_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.checklist_items (id, checklist_id, description, category, is_mandatory, is_completed, completed_by, completed_at, evidence_document_id) FROM stdin;
\.


--
-- Data for Name: client_complaints; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.client_complaints (id, complaint_id, date_raised, client_id, reference_type, reference_id, complaint_type, severity, description, root_cause, status, owner_id, closure_date, notes, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: client_feedbacks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.client_feedbacks (id, feedback_id, date, client_id, reference_type, reference_id, overall_rating, quality_rating, timeliness_rating, communication_rating, would_recommend, comments, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: clients; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.clients (id, name, code, address, city, state, pincode, country, gst_number, primary_email, primary_phone, notes, is_active, created_at, updated_at, deleted_at, business_id, industry, date_onboarded, client_status, first_lead_id, first_inquiry_id) FROM stdin;
41c2e397-2cf6-4a8d-9cd2-9db1f779f172	Tata Chemicals Ltd	TCL-001	Industrial Estate, Mithapur	Mithapur	Gujarat	390337	India	24AAACT1234A1Z5	procurement@tatachemicals.com	+91 22 6665 8282		t	2026-05-20 16:57:27.26774+05:30	2026-05-20 16:57:27.26774+05:30	\N	\N	\N	\N	Active	\N	\N
4c11e2d6-052b-426a-9616-48a33b6f1c8c	Adani Power Mundra	APM-002	Industrial Estate, Mundra	Mundra	Gujarat	383668	India	24AABCA1234B1Z6	projects@adani.com	+91 79 2656 5555		t	2026-05-20 16:57:27.26774+05:30	2026-05-20 16:57:27.26774+05:30	\N	\N	\N	\N	Active	\N	\N
1fe18042-f7a1-469f-a4fd-f5c66be95c3b	Reliance Industries Ltd	RIL-003	Industrial Estate, Jamnagar	Jamnagar	Gujarat	379343	India	27AAACR1234C1Z7	engineering@ril.com	+91 22 2278 5000		t	2026-05-20 16:57:27.26774+05:30	2026-05-20 16:57:27.26774+05:30	\N	\N	\N	\N	Active	\N	\N
01560241-e3b9-416f-bf56-346740c15644	Gujarat State Fertilizers	GSF-004	Industrial Estate, Vadodara	Vadodara	Gujarat	363771	India	24AABCG1234D1Z8	maintenance@gsfc.in	+91 265 242 2700		t	2026-05-20 16:57:27.26774+05:30	2026-05-20 16:57:27.26774+05:30	\N	\N	\N	\N	Active	\N	\N
f7115ec8-0495-48e0-8c78-9596b6e6843c	Ambuja Cements Ltd	ACL-005	Industrial Estate, Ambuja Nagar	Ambuja Nagar	Gujarat	379211	India	24AAACA1234E1Z9	technical@ambujacement.com	+91 79 2646 2400		t	2026-05-20 16:57:27.26774+05:30	2026-05-20 16:57:27.26774+05:30	\N	\N	\N	\N	Active	\N	\N
33965868-0a3a-4b3c-b9a3-18212535f76d	Suzlon Energy Ltd	SEL-006	Industrial Estate, Pune	Pune	Maharashtra	376764	India	27AABCS1234F1Z0	ops@suzlon.com	+91 20 4012 2000		t	2026-05-20 16:57:27.26774+05:30	2026-05-20 16:57:27.26774+05:30	\N	\N	\N	\N	Active	\N	\N
6aeeb19d-a6b3-4723-acfc-8ac560c9ac24	Torrent Power Ltd	TPL-007	Industrial Estate, Ahmedabad	Ahmedabad	Gujarat	377960	India	24AABCT1234G1Z1	civil@torrentpower.com	+91 79 2687 2100		t	2026-05-20 16:57:27.26774+05:30	2026-05-20 16:57:27.26774+05:30	\N	\N	\N	\N	Active	\N	\N
9761e17d-e778-49bb-9287-8008e61b922a	Deepak Nitrite Ltd	DNL-008	Industrial Estate, Nandesari	Nandesari	Gujarat	383850	India	24AAACD1234H1Z2	projects@deepaknitrite.com	+91 265 398 0100		t	2026-05-20 16:57:27.26774+05:30	2026-05-20 16:57:27.26774+05:30	\N	\N	\N	\N	Active	\N	\N
733612ac-fc9a-4299-acdb-4960bf37a4c3	Larsen & Toubro Ltd	LNT-009	Industrial Estate, Surat	Surat	Gujarat	380433	India	24AAACL1234I1Z3	insulation@ltconstruction.com	+91 22 6752 5656		t	2026-05-20 16:57:27.26774+05:30	2026-05-20 16:57:27.26774+05:30	\N	\N	\N	\N	Active	\N	\N
083b968b-5273-4041-88db-42f249a0dcdf	Welspun India Ltd	WIL-010	Industrial Estate, Anjar	Anjar	Gujarat	375129	India	24AAACW1234J1Z4	facilities@welspun.com	+91 2836 270 001		t	2026-05-20 16:57:27.26774+05:30	2026-05-20 16:57:27.26774+05:30	\N	\N	\N	\N	Active	\N	\N
bc2188d6-8323-4466-a495-163470623339	Demo Client	DEMO-999	\N	\N	\N	\N	India	\N	demo@example.com	\N	\N	t	2026-05-20 17:05:00.969594+05:30	2026-05-20 17:05:01.011232+05:30	2026-05-20 11:35:01.012756+05:30	\N	\N	\N	Active	\N	\N
c6b18532-8987-49de-9080-04a426e2b144	Tata Chemicals Ltd	SWA-CL-001	Industrial Estate, Gujarat	\N	\N	\N	India	\N	procurement@tatachemicals.com	+91 22 6665 8282	\N	t	2026-06-27 11:53:55.284358+05:30	2026-06-27 11:53:55.284358+05:30	\N	SWA-CL-001	Chemicals	2025-12-29	Active	\N	\N
e8caee77-2da6-4c64-876e-37957b0fc6f6	Adani Power Mundra	SWA-CL-002	Industrial Estate, Gujarat	\N	\N	\N	India	\N	projects@adani.com	+91 79 2656 5555	\N	t	2026-06-27 11:53:55.284358+05:30	2026-06-27 11:53:55.284358+05:30	\N	SWA-CL-002	Power	2025-12-29	Active	\N	\N
c88b04f4-342a-477b-b4dd-5eccc72db2b7	Reliance Industries Ltd	SWA-CL-003	Industrial Estate, Gujarat	\N	\N	\N	India	\N	engineering@ril.com	+91 22 2278 5000	\N	t	2026-06-27 11:53:55.284358+05:30	2026-06-27 11:53:55.284358+05:30	\N	SWA-CL-003	Oil & Gas	2025-12-29	Active	\N	\N
\.


--
-- Data for Name: compliance_checklist_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.compliance_checklist_items (id, standard_id, category, requirement, description, is_mandatory, created_at) FROM stdin;
\.


--
-- Data for Name: compliance_checklists; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.compliance_checklists (id, project_id, template_id, status, completed_at, created_at) FROM stdin;
\.


--
-- Data for Name: compliance_standards; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.compliance_standards (id, name, version, description, created_at) FROM stdin;
\.


--
-- Data for Name: compliance_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.compliance_templates (id, name, standard_code, category, is_active, items, created_at) FROM stdin;
\.


--
-- Data for Name: contacts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contacts (id, client_id, name, email, phone, designation, is_primary, created_at, updated_at) FROM stdin;
9e427472-b91e-46c8-8f2a-1d6c568d5fbf	41c2e397-2cf6-4a8d-9cd2-9db1f779f172	Amit Kumar	amit.kumar@tatachemic.com	+91 92389 99778	HOD - Technical	t	2026-05-20 16:57:27.26774+05:30	2026-05-20 16:57:27.26774+05:30
1dea070f-e466-4767-84ca-b99ad98649e9	41c2e397-2cf6-4a8d-9cd2-9db1f779f172	Suresh Patel	suresh.patel@tatachemic.com	+91 85320 96450	Project Manager	f	2026-05-20 16:57:27.26774+05:30	2026-05-20 16:57:27.26774+05:30
6cd5a482-e075-45ca-a05f-3217eb60c480	41c2e397-2cf6-4a8d-9cd2-9db1f779f172	Vikram Singh	vikram.singh@tatachemic.com	+91 96221 98449	Maintenance Head	f	2026-05-20 16:57:27.26774+05:30	2026-05-20 16:57:27.26774+05:30
1ee37c16-77d6-4add-9b56-76cd79bd5ce8	4c11e2d6-052b-426a-9616-48a33b6f1c8c	Pooja Shah	pooja.shah@adanipower.com	+91 87266 24279	Project Manager	f	2026-05-20 16:57:27.26774+05:30	2026-05-20 16:57:27.26774+05:30
0b25989e-d41e-46ce-bb2e-7676266d7355	4c11e2d6-052b-426a-9616-48a33b6f1c8c	Manish Joshi	manish.joshi@adanipower.com	+91 82752 36408	HOD - Technical	f	2026-05-20 16:57:27.26774+05:30	2026-05-20 16:57:27.26774+05:30
6b9a68ac-6f2a-4543-b073-896b88438378	1fe18042-f7a1-469f-a4fd-f5c66be95c3b	Kiran Rao	kiran.rao@reliancein.com	+91 79094 58901	Maintenance Head	f	2026-05-20 16:57:27.26774+05:30	2026-05-20 16:57:27.26774+05:30
527ad3cd-81b6-4063-9017-74f709a4b27d	1fe18042-f7a1-469f-a4fd-f5c66be95c3b	Divya Iyer	divya.iyer@reliancein.com	+91 81367 21089	Maintenance Head	f	2026-05-20 16:57:27.26774+05:30	2026-05-20 16:57:27.26774+05:30
65c6fc13-4d8a-46cc-bfc3-f68f5cc6f30d	1fe18042-f7a1-469f-a4fd-f5c66be95c3b	Sanjay Bhatt	sanjay.bhatt@reliancein.com	+91 73417 48565	HOD - Technical	f	2026-05-20 16:57:27.26774+05:30	2026-05-20 16:57:27.26774+05:30
317edd73-1503-4f17-9f9e-8f440b05cef4	01560241-e3b9-416f-bf56-346740c15644	Meera Jain	meera.jain@gujaratsta.com	+91 78476 22858	Project Manager	f	2026-05-20 16:57:27.26774+05:30	2026-05-20 16:57:27.26774+05:30
cd8dc6bc-cbaa-46bb-a05c-ca30276e119f	01560241-e3b9-416f-bf56-346740c15644	Arjun Nair	arjun.nair@gujaratsta.com	+91 96132 89150	HOD - Technical	f	2026-05-20 16:57:27.26774+05:30	2026-05-20 16:57:27.26774+05:30
80b7ea8f-37e2-4b42-8dc1-f428f9401332	f7115ec8-0495-48e0-8c78-9596b6e6843c	Bhavesh Modi	bhavesh.modi@ambujaceme.com	+91 99126 70576	HOD - Technical	f	2026-05-20 16:57:27.26774+05:30	2026-05-20 16:57:27.26774+05:30
b847fd01-b134-4c95-992e-f3de21dd8c29	f7115ec8-0495-48e0-8c78-9596b6e6843c	Hetal Desai	hetal.desai@ambujaceme.com	+91 97495 15848	Maintenance Head	f	2026-05-20 16:57:27.26774+05:30	2026-05-20 16:57:27.26774+05:30
5a0295de-1576-49c1-91f6-076229eb604b	33965868-0a3a-4b3c-b9a3-18212535f76d	Jayesh Thakkar	jayesh.thakkar@suzlonener.com	+91 89417 25443	HOD - Technical	f	2026-05-20 16:57:27.26774+05:30	2026-05-20 16:57:27.26774+05:30
11a14420-d776-4e7e-bf07-91eb54192738	33965868-0a3a-4b3c-b9a3-18212535f76d	Kamal Trivedi	kamal.trivedi@suzlonener.com	+91 74198 92116	Project Manager	f	2026-05-20 16:57:27.26774+05:30	2026-05-20 16:57:27.26774+05:30
762382f2-3e30-4f08-8816-410981a35a45	33965868-0a3a-4b3c-b9a3-18212535f76d	Leela Menon	leela.menon@suzlonener.com	+91 86554 39263	Plant Engineer	f	2026-05-20 16:57:27.26774+05:30	2026-05-20 16:57:27.26774+05:30
7ff7f833-9ed0-45ea-902f-b80253a97368	6aeeb19d-a6b3-4723-acfc-8ac560c9ac24	Amit Kumar	amit.kumar@torrentpow.com	+91 70494 81868	Plant Engineer	f	2026-05-20 16:57:27.26774+05:30	2026-05-20 16:57:27.26774+05:30
ec513213-a4d1-45a6-ab1a-28eb898de0bf	6aeeb19d-a6b3-4723-acfc-8ac560c9ac24	Suresh Patel	suresh.patel@torrentpow.com	+91 89812 54282	Procurement Officer	f	2026-05-20 16:57:27.26774+05:30	2026-05-20 16:57:27.26774+05:30
079fde66-9df5-4e48-9ead-234d458325b0	9761e17d-e778-49bb-9287-8008e61b922a	Vikram Singh	vikram.singh@deepaknitr.com	+91 87116 85866	Plant Engineer	f	2026-05-20 16:57:27.26774+05:30	2026-05-20 16:57:27.26774+05:30
bf4968d7-867d-4e74-851a-cb46ca3b6faf	9761e17d-e778-49bb-9287-8008e61b922a	Pooja Shah	pooja.shah@deepaknitr.com	+91 88698 52365	Procurement Officer	f	2026-05-20 16:57:27.26774+05:30	2026-05-20 16:57:27.26774+05:30
2aec12e1-147f-40ab-a304-e9af1bbb9f8f	733612ac-fc9a-4299-acdb-4960bf37a4c3	Manish Joshi	manish.joshi@larsen&tou.com	+91 72811 20148	Maintenance Head	f	2026-05-20 16:57:27.26774+05:30	2026-05-20 16:57:27.26774+05:30
adba230c-abdb-47e8-9d4f-3b07e310c15d	733612ac-fc9a-4299-acdb-4960bf37a4c3	Kiran Rao	kiran.rao@larsen&tou.com	+91 86450 64764	Procurement Officer	f	2026-05-20 16:57:27.26774+05:30	2026-05-20 16:57:27.26774+05:30
d65f3df9-b342-49a9-8d8a-9d7efd83174e	083b968b-5273-4041-88db-42f249a0dcdf	Divya Iyer	divya.iyer@welspunind.com	+91 77658 71107	Plant Engineer	f	2026-05-20 16:57:27.26774+05:30	2026-05-20 16:57:27.26774+05:30
42fe7abc-bf75-490f-9972-6ab79eeb4807	083b968b-5273-4041-88db-42f249a0dcdf	Sanjay Bhatt	sanjay.bhatt@welspunind.com	+91 73419 44650	Procurement Officer	f	2026-05-20 16:57:27.26774+05:30	2026-05-20 16:57:27.26774+05:30
d545d118-0f18-4f2a-8d2a-66edcc7b3c49	083b968b-5273-4041-88db-42f249a0dcdf	Meera Jain	meera.jain@welspunind.com	+91 85263 24780	Procurement Officer	f	2026-05-20 16:57:27.26774+05:30	2026-05-20 16:57:27.26774+05:30
07c99397-5b2a-46b8-a60a-b07036977cef	c6b18532-8987-49de-9080-04a426e2b144	Amit Kumar	amit.kumar@tata.com	+91 70000 10000	Project Manager	t	2026-06-27 11:53:55.284358+05:30	2026-06-27 11:53:55.284358+05:30
b55c8fb2-f481-4a27-a00e-daaf74c0844e	c6b18532-8987-49de-9080-04a426e2b144	Suresh Patel	suresh.patel@tata.com	+91 70001 10001	Plant Engineer	f	2026-06-27 11:53:55.284358+05:30	2026-06-27 11:53:55.284358+05:30
d17d357e-bd33-4506-afc9-40c387f16d35	e8caee77-2da6-4c64-876e-37957b0fc6f6	Pooja Shah	pooja.shah@adani.com	+91 70002 10002	Procurement Officer	f	2026-06-27 11:53:55.284358+05:30	2026-06-27 11:53:55.284358+05:30
84023837-f0ff-4d30-a5b8-b9864f393c58	e8caee77-2da6-4c64-876e-37957b0fc6f6	Vikram Singh	vikram.singh@adani.com	+91 70003 10003	Maintenance Head	t	2026-06-27 11:53:55.284358+05:30	2026-06-27 11:53:55.284358+05:30
d54bc6db-1a83-4515-9e0c-e4ac88f74899	c88b04f4-342a-477b-b4dd-5eccc72db2b7	Manish Joshi	manish.joshi@reliance.com	+91 70004 10004	HOD - Technical	f	2026-06-27 11:53:55.284358+05:30	2026-06-27 11:53:55.284358+05:30
47dee60b-bdb6-4b1d-a6ea-3d728683fac3	c88b04f4-342a-477b-b4dd-5eccc72db2b7	Kiran Rao	kiran.rao@reliance.com	+91 70005 10005	Project Manager	f	2026-06-27 11:53:55.284358+05:30	2026-06-27 11:53:55.284358+05:30
\.


--
-- Data for Name: document_folders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_folders (id, project_id, parent_id, name, created_at) FROM stdin;
\.


--
-- Data for Name: document_references; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_references (id, drn, project_id, token_id, document_type, document_name, document_reference, document_date, uploaded_by, access_level, description, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.documents (id, project_id, name, original_name, file_path, category, version, previous_version_id, size_bytes, mime_type, uploaded_by, uploaded_at, is_deleted) FROM stdin;
\.


--
-- Data for Name: drn; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.drn (id, drn_code, doc_type, date, associated_project_id, associated_token_id, author_id, document_nature, intended_user, description, revision, status, remarks, file_path, created_at, updated_at, deleted_at, is_deleted) FROM stdin;
e0adad4d-f29f-4bd3-b1c9-3afcf2b824d3	SWA-2026-001/CON	Concept Note	2026-06-12 00:00:00+05:30	8304a532-22ff-40b4-931a-5a80897668a6	\N	\N	Submittal	Client	Concept note — boiler insulation retrofit scope and approach	R0	Issued	\N	\N	2026-06-27 11:53:55.284358+05:30	2026-06-27 11:53:55.284358+05:30	\N	f
651e9439-752e-4051-9f5f-242c1775bd45	SWA-2026-001/DBR	Design Basis Report	2026-06-12 00:00:00+05:30	8304a532-22ff-40b4-931a-5a80897668a6	\N	\N	Internal	Internal	Design basis — material grades, thermal parameters, IS compliance	R0	Under Review	\N	\N	2026-06-27 11:53:55.284358+05:30	2026-06-27 11:53:55.284358+05:30	\N	f
5785800b-09dc-416b-9330-ec85e92adf1c	SWA-2026-001/CAS	Calculation Sheet	2026-06-12 00:00:00+05:30	8304a532-22ff-40b4-931a-5a80897668a6	\N	\N	Internal	Internal	Heat loss calculation — Unit 4 boiler walls	R0	Draft	\N	\N	2026-06-27 11:53:55.284358+05:30	2026-06-27 11:53:55.284358+05:30	\N	f
896ff245-2cd7-4c6e-b083-ce572c1c6043	SWA-2026-002/CON	Concept Note	2026-06-12 00:00:00+05:30	cfdd0c44-e645-4af6-aecb-e55fbf031f87	\N	\N	Submittal	Client	Concept note — STG cold insulation audit methodology	R0	Approved	\N	\N	2026-06-27 11:53:55.284358+05:30	2026-06-27 11:53:55.284358+05:30	\N	f
186ad82c-a010-4552-ada4-771652e49034	SWA-2026-002/GAD	GA Drawing	2026-06-12 00:00:00+05:30	cfdd0c44-e645-4af6-aecb-e55fbf031f87	\N	\N	Submittal	Reviewer	GA drawing — insulation zone layout and thermal map	R0	Under Review	\N	\N	2026-06-27 11:53:55.284358+05:30	2026-06-27 11:53:55.284358+05:30	\N	f
d4c89f30-1ae8-440f-bce4-f8dc5fdba146	SWA-2026-002/RPT	RPT	2026-06-12 00:00:00+05:30	cfdd0c44-e645-4af6-aecb-e55fbf031f87	\N	\N	Submittal	Client	Energy audit report — insulation efficiency findings	R0	Draft	\N	\N	2026-06-27 11:53:55.284358+05:30	2026-06-27 11:53:55.284358+05:30	\N	f
84cbd189-0475-4188-8e17-f3774e0373c7	SWA-2026-003/CON	Concept Note	2026-06-12 00:00:00+05:30	a19925f0-7821-47d1-b81d-c0fdb7fdfd5e	\N	\N	Submittal	Client	Concept note — reformer hot insulation consultation scope	R0	Issued	\N	\N	2026-06-27 11:53:55.284358+05:30	2026-06-27 11:53:55.284358+05:30	\N	f
71c854fb-b2ec-4590-b021-ec6ff0883cf6	SWA-2026-003/DBR	Design Basis Report	2026-06-12 00:00:00+05:30	a19925f0-7821-47d1-b81d-c0fdb7fdfd5e	\N	\N	Internal	Internal	Design basis — reformer piping thermal modelling parameters	R0	Draft	\N	\N	2026-06-27 11:53:55.284358+05:30	2026-06-27 11:53:55.284358+05:30	\N	f
\.


--
-- Data for Name: id_sequence; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.id_sequence (type_code, year, last_value) FROM stdin;
PRJ	2026	21
\.


--
-- Data for Name: inquiries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.inquiries (id, inquiry_id, inquiry_date, inquiry_type, inquiry_source, client_name, requirement_summary, estimated_value, priority, status, owner, technical_lead, notes, converted_to_client_id, converted_to_agreement_id, created_at, updated_at) FROM stdin;
f3ae47ff-bc37-4e2a-ac45-580937ceffd6	SWA-INQ-001	2026-05-28	Design	Referral	Tata Chemicals Ltd	Boiler insulation retrofit for Unit 4 — thermal design, material spec, and QA compliance per IS/ASTM standards.	2500000.00	High	Open	604daaee-2407-43c2-a1b2-049b758d661a	604daaee-2407-43c2-a1b2-049b758d661a	\N	\N	\N	2026-06-27 11:53:55.284358+05:30	2026-06-27 11:53:55.284358+05:30
56f4df4b-e011-415d-bbc8-0385d19756dc	SWA-INQ-002	2026-05-28	Audit	Website	Adani Power Mundra	Energy audit and insulation survey for STG Unit 3 cold systems. Includes thermal imaging and efficiency report.	800000.00	Medium	Qualified	604daaee-2407-43c2-a1b2-049b758d661a	604daaee-2407-43c2-a1b2-049b758d661a	\N	\N	\N	2026-06-27 11:53:55.284358+05:30	2026-06-27 11:53:55.284358+05:30
5cc14d8b-9a4a-40da-a226-0bda9cc2fabc	SWA-INQ-003	2026-05-28	Consultation	Direct	Reliance Industries Ltd	Reformer unit hot insulation consultation — material selection and heat-loss modelling for high-temperature process piping.	1500000.00	High	Converted	604daaee-2407-43c2-a1b2-049b758d661a	604daaee-2407-43c2-a1b2-049b758d661a	\N	\N	\N	2026-06-27 11:53:55.284358+05:30	2026-06-27 11:53:55.284358+05:30
22f0e104-e480-4cb7-8546-11818b458b05	SWA-INQ-004	2026-05-28	Design	LinkedIn	Tata Chemicals Ltd	Furnace wall lining replacement — complete refractory design and vendor coordination.	3200000.00	Medium	Open	604daaee-2407-43c2-a1b2-049b758d661a	604daaee-2407-43c2-a1b2-049b758d661a	\N	\N	\N	2026-06-27 11:53:55.284358+05:30	2026-06-27 11:53:55.284358+05:30
\.


--
-- Data for Name: instagram_metrics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.instagram_metrics (id, metric_id, period_yyyymm, followers_start, followers_end, followers_net_add, impressions, reach, profile_visits, likes, comments, shares, saves, engagement_rate, posts_count, reels_count, stories_count, website_clicks, inbound_dms, leads_count, inquiry_count, notes, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: invoice_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invoice_items (id, invoice_id, description, quantity, rate, amount, category, time_entry_id, created_at) FROM stdin;
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invoices (id, project_id, invoice_number, status, subtotal, tax_rate, tax_amount, total, currency, due_date, notes, created_by, paid_at, created_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: linkedin_metrics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.linkedin_metrics (id, metric_id, period_yyyymm, followers_start, followers_end, followers_net_add, impressions, reach, profile_views, reactions, comments, reposts, engagement_rate, posts_count, articles_count, videos_count, website_clicks, inbound_dms, leads_count, inquiry_count, notes, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: material_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.material_categories (id, name, description) FROM stdin;
\.


--
-- Data for Name: materials; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.materials (id, name, code, description, category_id, unit_id, specification, default_lead_time_days, is_active, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notifications (id, user_id, type, title, message, reference_type, reference_id, is_read, created_at) FROM stdin;
\.


--
-- Data for Name: project_compliance_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.project_compliance_items (id, project_id, checklist_item_id, status, evidence_document_id, notes, reviewed_by, reviewed_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: project_costs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.project_costs (id, project_id, category, description, amount, quantity, rate, reference_id, reference_type, date, created_by, created_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.projects (id, client_id, name, code, description, status, pm_id, designer_id, auditor_id, location, estimated_value, actual_value, start_date, target_end_date, actual_end_date, is_active, created_at, updated_at, deleted_at, business_id, milestone, progress_indicators, status_updates, team_leader_id, project_owner_id, notes) FROM stdin;
2f9ba78a-96a9-454a-9c9b-7fc2979eafb0	4c11e2d6-052b-426a-9616-48a33b6f1c8c	STG Unit 3 Cold Insulation	SWA-2025-002	STG Unit 3 Cold Insulation for Adani Power Mundra. Includes material supply, installation, and QA compliance as per IS/ASTM standards.	Quote	\N	\N	\N	Mundra, Gujarat	5300000.00	\N	2026-05-05	2026-07-25	\N	t	2026-05-20 16:57:27.26774+05:30	2026-05-20 16:57:27.26774+05:30	\N	SWA-2026-PRJ-001	Concept	\N	\N	\N	\N	\N
d3718457-f08d-4e1b-95b4-42742d7223fb	1fe18042-f7a1-469f-a4fd-f5c66be95c3b	Furnace Wall Lining Replacement	SWA-2025-003	Furnace Wall Lining Replacement for Reliance Industries Ltd. Includes material supply, installation, and QA compliance as per IS/ASTM standards.	Awarded	8e0c17cd-5487-416f-b795-caaf6d8e8a13	\N	\N	Jamnagar, Gujarat	14800000.00	\N	2026-04-20	2026-07-18	\N	t	2026-05-20 16:57:27.26774+05:30	2026-05-20 16:57:27.26774+05:30	\N	SWA-2026-PRJ-002	Concept	\N	\N	\N	\N	\N
57962a1e-b30a-49ac-a4fa-9f0f6c597135	01560241-e3b9-416f-bf56-346740c15644	HRSG Duct Insulation	SWA-2025-004	HRSG Duct Insulation for Gujarat State Fertilizers. Includes material supply, installation, and QA compliance as per IS/ASTM standards.	Design	8e0c17cd-5487-416f-b795-caaf6d8e8a13	b3ccbe51-aa77-48d9-9ee0-d9638f5c38c9	\N	Vadodara, Gujarat	500000.00	\N	2026-04-05	2026-06-10	\N	t	2026-05-20 16:57:27.26774+05:30	2026-05-20 16:57:27.26774+05:30	\N	SWA-2026-PRJ-003	Concept	\N	\N	\N	\N	\N
25de626c-ccf7-482e-bd00-6ab5a8f403f9	41c2e397-2cf6-4a8d-9cd2-9db1f779f172	Delete Me	DEL-999	\N	Lead	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	2026-05-20 17:05:01.02538+05:30	2026-05-20 17:05:01.040195+05:30	2026-05-20 11:35:01.041429+05:30	SWA-2026-PRJ-021	Concept	\N	\N	\N	\N	\N
4f3fc690-bcb2-44ef-9d05-42449d4dbe04	f7115ec8-0495-48e0-8c78-9596b6e6843c	Chilled Water Pipe Insulation	SWA-2025-005	Chilled Water Pipe Insulation for Ambuja Cements Ltd. Includes material supply, installation, and QA compliance as per IS/ASTM standards.	Vendor	8e0c17cd-5487-416f-b795-caaf6d8e8a13	b3ccbe51-aa77-48d9-9ee0-d9638f5c38c9	\N	Ambuja Nagar, Gujarat	4000000.00	\N	2026-03-21	2026-08-20	\N	t	2026-05-20 16:57:27.26774+05:30	2026-05-20 16:57:27.26774+05:30	\N	SWA-2026-PRJ-004	Concept	\N	\N	\N	\N	\N
9eb1e0e4-fbe7-4804-a859-d6d9106dddc9	33965868-0a3a-4b3c-b9a3-18212535f76d	Storage Tank Thermal Insulation	SWA-2025-006	Storage Tank Thermal Insulation for Suzlon Energy Ltd. Includes material supply, installation, and QA compliance as per IS/ASTM standards.	Execution	8e0c17cd-5487-416f-b795-caaf6d8e8a13	b3ccbe51-aa77-48d9-9ee0-d9638f5c38c9	\N	Pune, Maharashtra	13400000.00	\N	2026-03-06	2026-06-05	\N	t	2026-05-20 16:57:27.26774+05:30	2026-05-20 16:57:27.26774+05:30	\N	SWA-2026-PRJ-005	Concept	\N	\N	\N	\N	\N
e2d010d0-bb4f-45d6-a0c7-673778395680	6aeeb19d-a6b3-4723-acfc-8ac560c9ac24	Turbine Exhaust Duct Lining	SWA-2025-007	Turbine Exhaust Duct Lining for Torrent Power Ltd. Includes material supply, installation, and QA compliance as per IS/ASTM standards.	Validation	8e0c17cd-5487-416f-b795-caaf6d8e8a13	b3ccbe51-aa77-48d9-9ee0-d9638f5c38c9	0a3b4428-bb3c-439b-a1a6-1f9e82f3defa	Ahmedabad, Gujarat	700000.00	\N	2026-02-19	2026-08-15	\N	t	2026-05-20 16:57:27.26774+05:30	2026-05-20 16:57:27.26774+05:30	\N	SWA-2026-PRJ-006	Concept	\N	\N	\N	\N	\N
fd9d0d16-0fa4-45fa-b344-8312cafb349a	9761e17d-e778-49bb-9287-8008e61b922a	Ductwork Acoustic Treatment	SWA-2025-008	Ductwork Acoustic Treatment for Deepak Nitrite Ltd. Includes material supply, installation, and QA compliance as per IS/ASTM standards.	Closed	8e0c17cd-5487-416f-b795-caaf6d8e8a13	b3ccbe51-aa77-48d9-9ee0-d9638f5c38c9	0a3b4428-bb3c-439b-a1a6-1f9e82f3defa	Nandesari, Gujarat	8900000.00	8899410.48	2026-02-04	2026-04-27	2026-04-21	t	2026-05-20 16:57:27.26774+05:30	2026-05-20 16:57:27.26774+05:30	\N	SWA-2026-PRJ-007	Concept	\N	\N	\N	\N	\N
9c3fd1b8-5e35-4528-ae90-f0bbe459ad06	733612ac-fc9a-4299-acdb-4960bf37a4c3	Reformer Unit Hot Insulation	SWA-2025-009	Reformer Unit Hot Insulation for Larsen & Toubro Ltd. Includes material supply, installation, and QA compliance as per IS/ASTM standards.	Lead	\N	\N	\N	Surat, Gujarat	14200000.00	\N	\N	\N	\N	t	2026-05-20 16:57:27.26774+05:30	2026-05-20 16:57:27.26774+05:30	\N	SWA-2026-PRJ-008	Concept	\N	\N	\N	\N	\N
75559e3a-d553-4a65-87c8-446aa003ba58	083b968b-5273-4041-88db-42f249a0dcdf	Flare Stack Refractory Repair	SWA-2025-010	Flare Stack Refractory Repair for Welspun India Ltd. Includes material supply, installation, and QA compliance as per IS/ASTM standards.	Quote	\N	\N	\N	Anjar, Gujarat	11000000.00	\N	2026-05-05	2026-07-29	\N	t	2026-05-20 16:57:27.26774+05:30	2026-05-20 16:57:27.26774+05:30	\N	SWA-2026-PRJ-009	Concept	\N	\N	\N	\N	\N
6eb069ee-3d34-4eb5-879b-8a6b522e3f82	41c2e397-2cf6-4a8d-9cd2-9db1f779f172	Cooling Tower Basin Lining	SWA-2025-011	Cooling Tower Basin Lining for Tata Chemicals Ltd. Includes material supply, installation, and QA compliance as per IS/ASTM standards.	Awarded	8e0c17cd-5487-416f-b795-caaf6d8e8a13	\N	\N	Mithapur, Gujarat	1100000.00	\N	2026-04-20	2026-08-30	\N	t	2026-05-20 16:57:27.26774+05:30	2026-05-20 16:57:27.26774+05:30	\N	SWA-2026-PRJ-010	Concept	\N	\N	\N	\N	\N
f446a963-60b5-4fa1-a031-86f5edcd6181	4c11e2d6-052b-426a-9616-48a33b6f1c8c	Process Vessel Insulation	SWA-2025-012	Process Vessel Insulation for Adani Power Mundra. Includes material supply, installation, and QA compliance as per IS/ASTM standards.	Design	8e0c17cd-5487-416f-b795-caaf6d8e8a13	b3ccbe51-aa77-48d9-9ee0-d9638f5c38c9	\N	Mundra, Gujarat	1100000.00	\N	2026-04-05	2026-07-17	\N	t	2026-05-20 16:57:27.26774+05:30	2026-05-20 16:57:27.26774+05:30	\N	SWA-2026-PRJ-011	Concept	\N	\N	\N	\N	\N
73356e95-4a10-41d2-936c-5e39c11bc199	1fe18042-f7a1-469f-a4fd-f5c66be95c3b	Steam Distribution Line Insulation	SWA-2025-013	Steam Distribution Line Insulation for Reliance Industries Ltd. Includes material supply, installation, and QA compliance as per IS/ASTM standards.	Vendor	8e0c17cd-5487-416f-b795-caaf6d8e8a13	b3ccbe51-aa77-48d9-9ee0-d9638f5c38c9	\N	Jamnagar, Gujarat	7900000.00	\N	2026-03-21	2026-06-28	\N	t	2026-05-20 16:57:27.26774+05:30	2026-05-20 16:57:27.26774+05:30	\N	SWA-2026-PRJ-012	Concept	\N	\N	\N	\N	\N
ff85ffac-8854-421a-b81f-bf7e11d82141	01560241-e3b9-416f-bf56-346740c15644	Reactor Head Insulation	SWA-2025-014	Reactor Head Insulation for Gujarat State Fertilizers. Includes material supply, installation, and QA compliance as per IS/ASTM standards.	Execution	8e0c17cd-5487-416f-b795-caaf6d8e8a13	b3ccbe51-aa77-48d9-9ee0-d9638f5c38c9	\N	Vadodara, Gujarat	12200000.00	\N	2026-03-06	2026-08-27	\N	t	2026-05-20 16:57:27.26774+05:30	2026-05-20 16:57:27.26774+05:30	\N	SWA-2026-PRJ-013	Concept	\N	\N	\N	\N	\N
01598d31-6b8e-4c2b-9de1-31651e248cfa	f7115ec8-0495-48e0-8c78-9596b6e6843c	Preheat Train Cold Insulation	SWA-2025-015	Preheat Train Cold Insulation for Ambuja Cements Ltd. Includes material supply, installation, and QA compliance as per IS/ASTM standards.	Validation	8e0c17cd-5487-416f-b795-caaf6d8e8a13	b3ccbe51-aa77-48d9-9ee0-d9638f5c38c9	0a3b4428-bb3c-439b-a1a6-1f9e82f3defa	Ambuja Nagar, Gujarat	3000000.00	\N	2026-02-19	2026-05-10	\N	t	2026-05-20 16:57:27.26774+05:30	2026-05-20 16:57:27.26774+05:30	\N	SWA-2026-PRJ-014	Concept	\N	\N	\N	\N	\N
d9d0898a-d447-45d0-a0c2-25d92ddedcd2	33965868-0a3a-4b3c-b9a3-18212535f76d	Stack Emission Duct Lining	SWA-2025-016	Stack Emission Duct Lining for Suzlon Energy Ltd. Includes material supply, installation, and QA compliance as per IS/ASTM standards.	Closed	8e0c17cd-5487-416f-b795-caaf6d8e8a13	b3ccbe51-aa77-48d9-9ee0-d9638f5c38c9	0a3b4428-bb3c-439b-a1a6-1f9e82f3defa	Pune, Maharashtra	3300000.00	3054063.84	2026-02-04	2026-05-16	2026-05-10	t	2026-05-20 16:57:27.26774+05:30	2026-05-20 16:57:27.26774+05:30	\N	SWA-2026-PRJ-015	Concept	\N	\N	\N	\N	\N
c89b0f79-bf57-490a-b564-0298cefd0c18	6aeeb19d-a6b3-4723-acfc-8ac560c9ac24	Condensate Line Insulation	SWA-2025-017	Condensate Line Insulation for Torrent Power Ltd. Includes material supply, installation, and QA compliance as per IS/ASTM standards.	Lead	\N	\N	\N	Ahmedabad, Gujarat	11000000.00	\N	\N	\N	\N	t	2026-05-20 16:57:27.26774+05:30	2026-05-20 16:57:27.26774+05:30	\N	SWA-2026-PRJ-016	Concept	\N	\N	\N	\N	\N
7602b7eb-e9ee-4046-bd40-b531b3d9d764	9761e17d-e778-49bb-9287-8008e61b922a	Feedwater Heater Insulation	SWA-2025-018	Feedwater Heater Insulation for Deepak Nitrite Ltd. Includes material supply, installation, and QA compliance as per IS/ASTM standards.	Quote	\N	\N	\N	Nandesari, Gujarat	4200000.00	\N	2026-05-05	2026-08-23	\N	t	2026-05-20 16:57:27.26774+05:30	2026-05-20 16:57:27.26774+05:30	\N	SWA-2026-PRJ-017	Concept	\N	\N	\N	\N	\N
7a502500-5797-4a4b-8aca-9ea6a0b15f53	733612ac-fc9a-4299-acdb-4960bf37a4c3	Rotary Kiln Refractory Lining	SWA-2025-019	Rotary Kiln Refractory Lining for Larsen & Toubro Ltd. Includes material supply, installation, and QA compliance as per IS/ASTM standards.	Awarded	8e0c17cd-5487-416f-b795-caaf6d8e8a13	\N	\N	Surat, Gujarat	7700000.00	\N	2026-04-20	2026-07-18	\N	t	2026-05-20 16:57:27.26774+05:30	2026-05-20 16:57:27.26774+05:30	\N	SWA-2026-PRJ-018	Concept	\N	\N	\N	\N	\N
799befcd-6277-4aa2-af83-4b508f1c396d	083b968b-5273-4041-88db-42f249a0dcdf	ESP Hopper Insulation	SWA-2025-020	ESP Hopper Insulation for Welspun India Ltd. Includes material supply, installation, and QA compliance as per IS/ASTM standards.	Design	8e0c17cd-5487-416f-b795-caaf6d8e8a13	b3ccbe51-aa77-48d9-9ee0-d9638f5c38c9	\N	Anjar, Gujarat	11000000.00	\N	2026-04-05	2026-07-20	\N	t	2026-05-20 16:57:27.26774+05:30	2026-05-20 16:57:27.26774+05:30	\N	SWA-2026-PRJ-019	Concept	\N	\N	\N	\N	\N
2217b8e4-571e-4e71-b22d-956b401cdc7e	41c2e397-2cf6-4a8d-9cd2-9db1f779f172	Boiler Insulation Retrofit	SWA-2025-001	Boiler Insulation Retrofit for Tata Chemicals Ltd. Includes material supply, installation, and QA compliance as per IS/ASTM standards.	Quote	\N	\N	\N	Mithapur, Gujarat	6400000.00	\N	\N	\N	\N	t	2026-05-20 16:57:27.26774+05:30	2026-05-20 17:05:00.91571+05:30	\N	SWA-2026-PRJ-020	Concept	\N	\N	\N	\N	\N
8304a532-22ff-40b4-931a-5a80897668a6	c6b18532-8987-49de-9080-04a426e2b144	Boiler Insulation Retrofit — Tata Chemicals Unit 4	SWA-2026-001	\N	Design	8e0c17cd-5487-416f-b795-caaf6d8e8a13	\N	\N	Gujarat, India	2500000.00	\N	2026-03-29	2026-12-24	\N	t	2026-06-27 11:53:55.284358+05:30	2026-06-27 11:53:55.284358+05:30	\N	SWA-2026-001	DBR	\N	\N	\N	\N	\N
cfdd0c44-e645-4af6-aecb-e55fbf031f87	e8caee77-2da6-4c64-876e-37957b0fc6f6	STG Unit 3 Cold Insulation Audit — Adani Power	SWA-2026-002	\N	Execution	8e0c17cd-5487-416f-b795-caaf6d8e8a13	\N	\N	Gujarat, India	800000.00	\N	2026-03-29	2026-12-24	\N	t	2026-06-27 11:53:55.284358+05:30	2026-06-27 11:53:55.284358+05:30	\N	SWA-2026-002	Calculation	\N	\N	\N	\N	\N
a19925f0-7821-47d1-b81d-c0fdb7fdfd5e	c88b04f4-342a-477b-b4dd-5eccc72db2b7	Reformer Hot Insulation Consultation — Reliance	SWA-2026-003	\N	Awarded	8e0c17cd-5487-416f-b795-caaf6d8e8a13	\N	\N	Gujarat, India	1500000.00	\N	2026-03-29	2026-12-24	\N	t	2026-06-27 11:53:55.284358+05:30	2026-06-27 11:53:55.284358+05:30	\N	SWA-2026-003	Concept	\N	\N	\N	\N	\N
\.


--
-- Data for Name: quote_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.quote_items (id, quote_id, boq_item_id, line_number, category, description, specification, unit, quantity, rate, amount) FROM stdin;
\.


--
-- Data for Name: quotes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.quotes (id, project_id, boq_id, version_number, status, subtotal, markup_percent, markup_amount, tax_percent, tax_amount, total_amount, terms, validity_days, valid_until, created_by, approved_by, approved_at, sent_at, client_response, client_response_at, client_response_notes, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: reference_counters; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reference_counters (id, entity_type, year, last_seq) FROM stdin;
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.refresh_tokens (id, user_id, token_hash, expires_at, created_at, revoked_at) FROM stdin;
84d1d815-c42e-4246-ace2-ec9c22ccd34b	8e0c17cd-5487-416f-b795-caaf6d8e8a13	327281f0d051e4fe40f67ad6b49bc3b9093e5ba6914453e8dc8a4c02308da406	2026-06-18 23:54:03.901944+05:30	2026-05-19 23:54:03.423952+05:30	\N
56576de3-13b7-453a-a7c2-c0685ff80811	604daaee-2407-43c2-a1b2-049b758d661a	541b201cd08b38d951118a0b34c11ce3d04909b85e79bff13eb569300c9023bf	2026-06-18 23:54:03.902216+05:30	2026-05-19 23:54:03.424381+05:30	2026-05-19 23:54:04.63621+05:30
3b194793-54ec-4c9c-9d7a-8501afdba0eb	604daaee-2407-43c2-a1b2-049b758d661a	d7c7633f83ce8e0ce72f3dfb16d415c5293e3a91e3984dc909a3e0453a4783c4	2026-06-18 23:54:03.89717+05:30	2026-05-19 23:54:03.424583+05:30	2026-05-19 23:54:04.63621+05:30
9fdfbc90-e756-43df-a3e1-547c528a7b6e	8e0c17cd-5487-416f-b795-caaf6d8e8a13	cebd2c61e9e13507102a819837280a9cdfc95f2c6f5b977d73c5d4058e8fe58a	2026-06-18 23:56:18.991608+05:30	2026-05-19 23:56:18.736782+05:30	\N
15e235e1-fe64-45a8-a9db-266401d1000c	8e0c17cd-5487-416f-b795-caaf6d8e8a13	916b02f45108303b01d1d6a7183782ec07eb0b1f5fa970ef20bd6d6595a84ac5	2026-06-18 23:57:58.774258+05:30	2026-05-19 23:57:58.414943+05:30	\N
6797e652-2fc6-4715-a2de-673cf0e73a85	604daaee-2407-43c2-a1b2-049b758d661a	394c027dd3d763cf5179185007a1c05c05aed0ee4c1d1ea2dea6873a6c80fa23	2026-06-18 23:55:53.480763+05:30	2026-05-19 23:55:52.850981+05:30	2026-05-19 23:57:59.026318+05:30
5293268f-6110-4741-8f35-1108189cc33a	604daaee-2407-43c2-a1b2-049b758d661a	b565982c05db8eecab0b5505451a4bafeb6384e23acdcc5bb8d25427cb24a04a	2026-06-18 23:57:58.781128+05:30	2026-05-19 23:57:58.415315+05:30	2026-05-19 23:57:59.026318+05:30
629421b9-38d3-4837-af48-b0cf14a12bdd	604daaee-2407-43c2-a1b2-049b758d661a	b8ae11764ed1973fe6a872e89c0ac6a7ec07aad5ecf261ede126e570c6a535d0	2026-06-18 23:57:58.784174+05:30	2026-05-19 23:57:58.415858+05:30	2026-05-19 23:57:59.026318+05:30
eb0f8576-b4c5-4cc2-a017-56f030ec5c65	8e0c17cd-5487-416f-b795-caaf6d8e8a13	e1a34d95860dc3a8c3fd020b58f11ad69ebe06dcbf8637366df45607b26cb7e2	2026-06-18 23:58:39.072472+05:30	2026-05-19 23:58:38.706218+05:30	\N
7ca84bff-ab61-4a6c-b5db-83fb0b3e3503	604daaee-2407-43c2-a1b2-049b758d661a	868440eb627d16a6b304a740a74f71ec391d72941689aae2d1be04b9c64683b6	2026-06-18 23:58:39.068839+05:30	2026-05-19 23:58:38.706212+05:30	2026-05-19 23:58:39.343354+05:30
276146d4-8592-4b79-a026-518c846deb8f	604daaee-2407-43c2-a1b2-049b758d661a	7f90f4ae284860bcb4e28c342e2adfc45c76712937e78686967e1a6248171b48	2026-06-18 23:58:39.07269+05:30	2026-05-19 23:58:38.70615+05:30	2026-05-19 23:58:39.343354+05:30
5792d294-3d45-4aa0-88a3-396888710bac	8e0c17cd-5487-416f-b795-caaf6d8e8a13	eee6e9f04797feec3a348c7506cedc49d630c5e741d39a1ea9d785d1898537da	2026-06-19 14:43:08.045511+05:30	2026-05-20 14:43:05.257544+05:30	\N
24bfc1d6-251e-4360-8467-59b8b8165ceb	8e0c17cd-5487-416f-b795-caaf6d8e8a13	afb74e0ef8f291d69946d07ae5affee5a691d3f5d45096541bbaf8893f79d665	2026-06-19 14:46:09.04983+05:30	2026-05-20 14:46:05.011733+05:30	\N
cc1160bd-0551-40eb-8360-3a744e3e4888	604daaee-2407-43c2-a1b2-049b758d661a	5288520332c11f61213b99e079f2ef5c2361b8ceb0fe6f4b703b918b917357de	2026-06-19 14:43:07.969492+05:30	2026-05-20 14:43:05.259977+05:30	2026-05-20 14:46:10.224701+05:30
4b754962-6cab-47ef-a103-aa73c8eb3afe	604daaee-2407-43c2-a1b2-049b758d661a	b485cce905db7455a1ae9d4cf82d0b08a40b294a406eb740006c46733b940aa1	2026-06-19 14:43:08.185522+05:30	2026-05-20 14:43:05.521376+05:30	2026-05-20 14:46:10.224701+05:30
860bade3-cb08-4802-b89d-83c318ab9f52	604daaee-2407-43c2-a1b2-049b758d661a	e0f1db858aa14b9f6a0adc026fbafb04db7f86e5da36bccbdeefb88cc65bb3da	2026-06-19 14:43:29.424827+05:30	2026-05-20 14:43:28.532429+05:30	2026-05-20 14:46:10.224701+05:30
feb26469-a156-4f24-9f44-8b773dec4cc2	604daaee-2407-43c2-a1b2-049b758d661a	cafe02f7c930edf6bed47b587eef5adcdcecc08ed710252da849e991076215f4	2026-06-19 14:43:36.060822+05:30	2026-05-20 14:43:35.109173+05:30	2026-05-20 14:46:10.224701+05:30
6df0d010-ca4a-475e-a72d-c79a44b64516	604daaee-2407-43c2-a1b2-049b758d661a	12f93e59b982fea74e8851ffdf1f69df9a261a32fb0076db79df8d1e11c49628	2026-06-19 14:46:08.934133+05:30	2026-05-20 14:46:04.989858+05:30	2026-05-20 14:46:10.224701+05:30
06ee2d2d-06f4-4676-980c-22c78a15fc28	604daaee-2407-43c2-a1b2-049b758d661a	328d1d2d8066ad51bb2cb2a5495b722af3bfdbe9748b1943fc927ab02ff5d9b9	2026-06-19 14:46:09.105383+05:30	2026-05-20 14:46:07.649288+05:30	2026-05-20 14:46:10.224701+05:30
140a91db-6af1-4466-8ddb-59fab9983e31	8e0c17cd-5487-416f-b795-caaf6d8e8a13	534072588c4d06c4eb98d3307df81667e9018757fcfa5e8a4d7b50922a71145e	2026-06-19 14:47:12.877117+05:30	2026-05-20 14:47:03.092874+05:30	\N
4dc01fae-840b-43aa-9727-a5edb83cadb0	8e0c17cd-5487-416f-b795-caaf6d8e8a13	fb51c3ab749a9989179100177eeef0e12982ac6114a9d20d9323c90254bfe34d	2026-06-19 14:53:32.247508+05:30	2026-05-20 14:53:20.376915+05:30	\N
238fb667-7e3a-4184-ba96-1ed7f86525a3	8e0c17cd-5487-416f-b795-caaf6d8e8a13	8b0e50cbcf8a9c820f5d8c6aab5ad41eb84dfc23629416e206f0ce96ccda9a0b	2026-06-19 14:55:33.122939+05:30	2026-05-20 14:55:31.344122+05:30	\N
e336ba8e-b6d7-4a69-89f7-51b02c32be58	604daaee-2407-43c2-a1b2-049b758d661a	d4f7334134c5f9fd70b1583ebda158a0542add3a8e167b9daa5db25302b55fac	2026-06-19 14:47:12.870119+05:30	2026-05-20 14:47:03.189829+05:30	2026-05-20 14:55:36.234631+05:30
cff4e571-79fa-4a2e-963d-d54637d1ee1c	604daaee-2407-43c2-a1b2-049b758d661a	6caaa0eb9d62140beb129deb87eeb024e2ae63942ab181c8ea8218c8aa30203f	2026-06-19 14:47:13.518248+05:30	2026-05-20 14:47:03.158749+05:30	2026-05-20 14:55:36.234631+05:30
d326e8e6-6db5-47ef-9f83-791de42c4449	604daaee-2407-43c2-a1b2-049b758d661a	47d63076d08b931f6b434c4eca574f956d12b9243e3181f57a411161d2822420	2026-06-19 14:49:44.375098+05:30	2026-05-20 14:49:42.07341+05:30	2026-05-20 14:55:36.234631+05:30
0d38079a-f175-4c3c-9913-a7b18a41ff62	604daaee-2407-43c2-a1b2-049b758d661a	c4dcd8fa101da3f213095aa3aed13d64bd4eac6d421465985fe902f0f0f799c6	2026-06-19 14:52:19.030369+05:30	2026-05-20 14:52:18.061336+05:30	2026-05-20 14:55:36.234631+05:30
3b182e22-e67c-490d-aec0-1633bfebb815	604daaee-2407-43c2-a1b2-049b758d661a	bab491cbc5546ffdc924576c7e672209551bfabcb04483398ae979be6e11850c	2026-06-19 14:53:32.399813+05:30	2026-05-20 14:53:21.821512+05:30	2026-05-20 14:55:36.234631+05:30
96296d91-394b-4bfc-a500-22e3bed73102	604daaee-2407-43c2-a1b2-049b758d661a	491ca5d348dbb0abc26992faee315749a53cf2016693d94c6662f406f53e55dc	2026-06-19 14:53:42.38696+05:30	2026-05-20 14:53:37.230788+05:30	2026-05-20 14:55:36.234631+05:30
7b2bef7d-5396-4b29-bfa2-d743790935ad	604daaee-2407-43c2-a1b2-049b758d661a	2d0c4d04f4dc135d28c0b7deb16a726c4656b82138eaa602c154ebea1ed655b7	2026-06-19 14:54:13.050619+05:30	2026-05-20 14:54:12.063402+05:30	2026-05-20 14:55:36.234631+05:30
ebf17bde-93f6-41ce-a657-b8989361e9cd	604daaee-2407-43c2-a1b2-049b758d661a	ad1fad50b1a766fa99e36c3867b5ba34f51309a42ae9d407dc20320ada14eab5	2026-06-19 14:55:33.127337+05:30	2026-05-20 14:55:31.342646+05:30	2026-05-20 14:55:36.234631+05:30
5e0cc554-8da3-4026-a048-b5157c7af161	604daaee-2407-43c2-a1b2-049b758d661a	1c960c85e4e0f6b6be39a5bfa6b978c442a6c7f785b2c26c4bd0e3ea0090da74	2026-06-19 14:55:33.099965+05:30	2026-05-20 14:55:31.343212+05:30	2026-05-20 14:55:36.234631+05:30
c3f4d30a-5009-404d-a7c7-d8f0a09419e7	604daaee-2407-43c2-a1b2-049b758d661a	a13036e69104d514fedbd19cf51816dce6f0e2d4a608aab5d9e6aabaa5cf888a	2026-06-19 14:55:35.395966+05:30	2026-05-20 14:55:33.341231+05:30	2026-05-20 14:55:36.234631+05:30
cfa3afa8-ea04-4cba-93e9-64ddf7e657bd	8e0c17cd-5487-416f-b795-caaf6d8e8a13	aa4acc46a53881060a92248b40a4f2516ab170ecf16d16c16aeb3018fb180fbb	2026-06-19 17:04:59.650597+05:30	2026-05-20 17:04:59.356993+05:30	\N
c15a720e-aa6b-4fc4-ba27-32d342e23980	b3ccbe51-aa77-48d9-9ee0-d9638f5c38c9	8a9df2cd236cdb27d4a069756a60193dfc4313f0b38e5827a4cf233661ce4200	2026-06-19 17:04:59.961259+05:30	2026-05-20 17:04:59.665307+05:30	\N
af6f2343-7f0d-4f73-ad2a-174333ac4e22	0a3b4428-bb3c-439b-a1a6-1f9e82f3defa	86e81788f655c898361bd92c314b87629671053154fc24fad0319b125444d431	2026-06-19 17:05:00.353002+05:30	2026-05-20 17:04:59.976407+05:30	\N
305c54a3-e5ff-4deb-9863-70ae0cb210e5	3ba9a171-6f96-4e11-9b35-f5ce4924a1d7	491ca18d83fe1db30f5173cf679f9ad66d26cb8fd2d72b9d8f100e0762c9f968	2026-06-19 17:05:00.704367+05:30	2026-05-20 17:05:00.368284+05:30	\N
eb6b1ea9-17a8-440c-acf0-0d9c6539d79f	8e0c17cd-5487-416f-b795-caaf6d8e8a13	384e4b3757e7a690090b584961c340ee941bfe7b89f64ece99c3e9e8e13e1517	2026-06-19 17:06:04.108852+05:30	2026-05-20 17:06:03.484835+05:30	\N
c6c49d5d-8514-4ca3-8cac-132c7ef1bc46	604daaee-2407-43c2-a1b2-049b758d661a	4b651888b407c6cc213630f6b9825dfbf6d51f0674dfbac78c0672795283a1be	2026-06-19 16:59:55.947566+05:30	2026-05-20 16:59:55.624187+05:30	2026-05-20 17:06:04.862619+05:30
e587d9ff-6e63-478f-bbcc-bf40321210a8	604daaee-2407-43c2-a1b2-049b758d661a	212be61dc87e9ef52270f2551c4beac27ff9207698b43eb27a54a70801dbd232	2026-06-19 17:00:02.890486+05:30	2026-05-20 17:00:02.638552+05:30	2026-05-20 17:06:04.862619+05:30
8ef3c9cf-c03e-4a1f-b6ce-4fc75ca86614	604daaee-2407-43c2-a1b2-049b758d661a	e73bc11e82da0f72cbf26ddeabc4cef97ba458035be2b98df67ee48a1db214c5	2026-06-19 17:00:13.386728+05:30	2026-05-20 17:00:13.130963+05:30	2026-05-20 17:06:04.862619+05:30
1c68438b-55b7-48e5-a23d-db7edbc69d54	604daaee-2407-43c2-a1b2-049b758d661a	fb4f7886a1cb133d1a83a3c4d939e671b30c4ef3d0770d75049230d49fa16ca0	2026-06-19 17:04:59.288691+05:30	2026-05-20 17:04:59.0051+05:30	2026-05-20 17:06:04.862619+05:30
f89a72eb-3297-4598-b78f-fbe170489814	604daaee-2407-43c2-a1b2-049b758d661a	e134497710adf0ed51a505c134089979b25e77cd4f8494d91ff133b6af9cf1de	2026-06-19 17:06:04.035657+05:30	2026-05-20 17:06:03.484562+05:30	2026-05-20 17:06:04.862619+05:30
f73efc6b-422f-40fe-ac26-40759293643c	604daaee-2407-43c2-a1b2-049b758d661a	55ee7be668b4a809983e7cd28ad86fce2a45b1abaa83f3c6434133b70a591571	2026-06-19 17:06:04.087426+05:30	2026-05-20 17:06:03.484494+05:30	2026-05-20 17:06:04.862619+05:30
b8fa6c6b-57a2-426d-b61d-6d9aaa67f90e	604daaee-2407-43c2-a1b2-049b758d661a	1dd4898c1dad4d3fe5fcbfea72db8f1d1827d1c32a0cdf34b8c4a25ddf08b3a2	2026-06-19 17:06:04.649451+05:30	2026-05-20 17:06:04.038151+05:30	2026-05-20 17:06:04.862619+05:30
2579178a-4bb5-499e-ac68-26d5f0da786f	604daaee-2407-43c2-a1b2-049b758d661a	49e55616b5cfa21f1f0b0b40a58737b0b839c1615af9a97809de3f0bf9046faf	2026-06-19 17:11:38.368812+05:30	2026-05-20 17:11:38.090431+05:30	\N
27b29e1a-5bb9-498a-a0e4-0312b597d570	8e0c17cd-5487-416f-b795-caaf6d8e8a13	7b5c412ee35e2cec7a37b57a04b0952d38b5f6605c537cc39686ebfd87e67963	2026-06-20 15:59:30.144219+05:30	2026-05-21 15:59:29.883624+05:30	\N
f919d86f-daf0-418e-904d-9a82b1917156	604daaee-2407-43c2-a1b2-049b758d661a	972fd503ed934ebd3a0dc6f42cf7e9ac5adffa0ca5824528eab358d2bb1553e0	2026-06-20 17:58:03.754241+05:30	2026-05-21 17:58:02.702716+05:30	\N
fad23de5-02ad-490c-88d3-854cd5f46154	604daaee-2407-43c2-a1b2-049b758d661a	55437893c6a0c6587f92cc97831106df44d8d523d678a8e47602d0798ac49caa	2026-06-20 18:23:56.407909+05:30	2026-05-21 18:23:56.137848+05:30	\N
3d1c3d03-a8fc-4f8d-ab47-9b4bd4e1b645	604daaee-2407-43c2-a1b2-049b758d661a	d4d1c76d04c8c180fce01f45faf9e3374944713279943a6f06feae8b9b364755	2026-06-20 18:24:13.15884+05:30	2026-05-21 18:24:12.911823+05:30	\N
ab2920ec-0f8d-46b6-bc52-759c26395fe8	604daaee-2407-43c2-a1b2-049b758d661a	32e6a622edf8dc2544386a9995bdcf43ed4e4d00b5635d93b611bad1727b18bb	2026-06-20 18:26:38.031871+05:30	2026-05-21 18:26:37.78222+05:30	\N
34512b96-5437-4022-9eaf-f24db2b4384d	604daaee-2407-43c2-a1b2-049b758d661a	ec75f40f9983b45f252720d2ede3e42d8c2409a1e1661ac51b21bcd6be631e84	2026-06-20 18:28:29.390727+05:30	2026-05-21 18:28:28.502864+05:30	\N
26af0036-052e-4af5-b2a5-31913e9af83b	604daaee-2407-43c2-a1b2-049b758d661a	c233ed8aa224378badc189acfa0e18d4601a4bd7610c96b83e6ba3aaf70458f3	2026-06-20 18:30:05.43194+05:30	2026-05-21 18:30:05.046764+05:30	\N
4f72fc40-553b-46f0-9337-6849c6d6553d	604daaee-2407-43c2-a1b2-049b758d661a	004b1215821008fb0daca4abb95131cd462c512101bb746cdd282a858cabc28a	2026-06-20 18:31:55.588352+05:30	2026-05-21 18:31:55.326778+05:30	\N
c4636a7f-554d-453c-97c8-ceaa8e6f03a1	604daaee-2407-43c2-a1b2-049b758d661a	5e0208c178956d54f84764775813ec3b64df61527213257c209b52e3d5cbeb66	2026-06-21 13:42:40.966868+05:30	2026-05-22 13:42:40.514048+05:30	\N
9fa255b1-9c4f-4232-b9df-e76161ba4256	8e0c17cd-5487-416f-b795-caaf6d8e8a13	27203b1c334b37746d4b5771871a90c0b02b2904a37f653121b596f80f246fcd	2026-08-03 16:04:36.57712+05:30	2026-07-04 16:04:36.324085+05:30	\N
94147bbb-0236-4c85-9eb4-07e86299cf0f	3ba9a171-6f96-4e11-9b35-f5ce4924a1d7	73b6aee2d28bf863046237a7ae63b42361497e5f16448764135434082608bea2	2026-08-03 16:04:36.888804+05:30	2026-07-04 16:04:36.640204+05:30	\N
95864dbf-34a2-4903-bea8-7ed5dea0f3c1	8e0c17cd-5487-416f-b795-caaf6d8e8a13	c9bcdc42f5817e2f4091d50bab8a092ae2df226ebb85efdfcba826d33875a868	2026-08-03 16:04:38.210666+05:30	2026-07-04 16:04:37.965129+05:30	\N
58376505-58d6-4b59-a64e-1ed2d2f14bb9	b3ccbe51-aa77-48d9-9ee0-d9638f5c38c9	fcbfd9109e6c55c4092003fc9e1ee95a9e67a9078d8dcf6c0471179c2376d9ab	2026-08-03 16:04:38.455719+05:30	2026-07-04 16:04:38.215828+05:30	\N
\.


--
-- Data for Name: research_collaborations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.research_collaborations (id, collab_id, institution_name, institution_type, department_or_lab, faculty_or_pi_name, collab_type, collab_objective, domain, start_date, end_date, collab_status, engagement_model, linked_innovation_id, linked_project_id, primary_internal_owner_id, secondary_internal_owner_id, expected_output, actual_output, notes, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: research_innovations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.research_innovations (id, innovation_id, innovation_title, innovation_type, domain, problem_statement, innovation_trigger, start_date, concept_freeze_date, validation_complete_date, rollout_date, time_to_market_days, innovation_status, commercialization_status, linked_project_id, linked_client_id, primary_owner_id, secondary_owner_id, notes, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: rfq_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.rfq_items (id, rfq_id, material_id, boq_item_id, description, unit, quantity, target_rate, notes, created_at) FROM stdin;
\.


--
-- Data for Name: rfq_responses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.rfq_responses (id, rfq_id, vendor_id, status, unit_price, total_price, delivery_days, validity_days, notes, submitted_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: rfqs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.rfqs (id, project_id, quote_id, title, status, submission_deadline, notes, created_by, awarded_to_vendor_id, sent_at, closed_at, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: service_agreements; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.service_agreements (id, agreement_id, client_id, inquiry_id, service_name, start_date, end_date, total_tokens, billing_model, status, notes, created_at, updated_at) FROM stdin;
e818cab2-60be-45d1-9bf0-f010c641c2bd	SWA-SA-001	c6b18532-8987-49de-9080-04a426e2b144	f3ae47ff-bc37-4e2a-ac45-580937ceffd6	Boiler Insulation Design & Supply	2026-02-27	2026-12-24	6.00	Per Token	Active	\N	2026-06-27 11:53:55.284358+05:30	2026-06-27 11:53:55.284358+05:30
3eec4ded-d7fb-43d2-9b56-6a4dbf1db440	SWA-SA-002	e8caee77-2da6-4c64-876e-37957b0fc6f6	56f4df4b-e011-415d-bbc8-0385d19756dc	STG Energy Audit & Insulation Survey	2026-03-29	2026-09-25	4.00	Per Token	Active	\N	2026-06-27 11:53:55.284358+05:30	2026-06-27 11:53:55.284358+05:30
67285f9b-cf72-4abb-9b65-6e88bc31ed16	SWA-SA-003	c88b04f4-342a-477b-b4dd-5eccc72db2b7	5cc14d8b-9a4a-40da-a226-0bda9cc2fabc	Reformer Insulation Consultation	2026-04-28	2026-10-25	5.00	Per Token	Active	\N	2026-06-27 11:53:55.284358+05:30	2026-06-27 11:53:55.284358+05:30
\.


--
-- Data for Name: sustainability_metrics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sustainability_metrics (id, reference_id, reference_kind, compliant_with_green_standards, total_energy_saved_kwh, co2_emissions_avoided_tco2e, lifecycle_cost_savings_inr, insulation_efficiency_actual_over_expected, insulation_efficiency_status, payback_period_months, measured_at, notes, created_at, updated_at, deleted_at) FROM stdin;
104d6c41-98b5-4e1a-a78f-d4ed9916e71a	SWA-2026-001	Project	IGBC, ECBC	12500.00	9.5000	1800000.00	1.120	Exceeded	18	2026-06-20	\N	2026-06-27 11:53:55.284358+05:30	2026-06-27 11:53:55.284358+05:30	\N
31edf082-e917-4093-9063-4f8d02965912	SWA-2026-002	Project	NBC, ECBC	8200.00	6.3000	950000.00	0.980	Below	24	2026-06-20	\N	2026-06-27 11:53:55.284358+05:30	2026-06-27 11:53:55.284358+05:30	\N
5eabfa9a-c4ae-407b-b896-11fe6c4c569d	SWA-2026-003	Project	IGBC	5600.00	4.2000	720000.00	1.050	Met	22	2026-06-20	\N	2026-06-27 11:53:55.284358+05:30	2026-06-27 11:53:55.284358+05:30	\N
\.


--
-- Data for Name: task_comments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.task_comments (id, task_id, author_id, parent_comment_id, content, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: task_dependencies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.task_dependencies (id, task_id, depends_on_task_id, created_at) FROM stdin;
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tasks (id, project_id, parent_id, title, description, status, priority, assignee_id, created_by, due_date, estimated_hours, actual_hours, boq_item_id, is_deleted, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: time_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.time_entries (id, project_id, task_id, user_id, date, hours, description, is_billable, created_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: time_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.time_log (id, log_date, employee_id, employee_role_at_log, work_type, reference_id, reference_kind, revision, project_name, activity_type, software_used, work_mode, hours_logged, billable_hours, remarks, created_at, updated_at) FROM stdin;
de47bf92-58e9-4f2f-9174-42193034ce8e	2026-06-17	604daaee-2407-43c2-a1b2-049b758d661a	AE	PROJECT	SWA-2026-001	Project	f	Boiler Insulation Retrofit	DBR	AutoCAD	Manual	8.00	8.00	Completed DBR draft	2026-06-27 11:53:55.284358+05:30	2026-06-27 11:53:55.284358+05:30
f88a19a8-aadf-4ca6-b3e8-cdfd9da538cc	2026-06-18	604daaee-2407-43c2-a1b2-049b758d661a	AE	PROJECT	SWA-2026-001	Project	f	Boiler Insulation Retrofit	CAL	Excel	Manual	6.00	6.00	Heat loss calc sheet	2026-06-27 11:53:55.284358+05:30	2026-06-27 11:53:55.284358+05:30
4592b9a4-b161-47b0-a8a3-75e84efc08f5	2026-06-19	8e0c17cd-5487-416f-b795-caaf6d8e8a13	PM	PROJECT	SWA-2026-002	Project	f	STG Cold Insulation Audit	MEET	Teams	Manual	2.00	2.00	Client kickoff call	2026-06-27 11:53:55.284358+05:30	2026-06-27 11:53:55.284358+05:30
8e60e53a-d688-4c37-820e-20969271ed29	2026-06-20	604daaee-2407-43c2-a1b2-049b758d661a	AE	PROJECT	SWA-2026-002	Project	f	STG Cold Insulation Audit	CON	AutoCAD	Manual	4.00	4.00	Concept sketches	2026-06-27 11:53:55.284358+05:30	2026-06-27 11:53:55.284358+05:30
be8a5a35-6c3e-4807-b127-cbb9b487d3de	2026-06-21	8e0c17cd-5487-416f-b795-caaf6d8e8a13	PM	PROJECT	SWA-2026-003	Project	f	Reformer Hot Insulation	MEET	Teams	Manual	1.50	1.50	Scope discussion	2026-06-27 11:53:55.284358+05:30	2026-06-27 11:53:55.284358+05:30
d91d77b3-0d5f-4b36-ad58-1c70ae634d91	2026-06-22	604daaee-2407-43c2-a1b2-049b758d661a	AE	PROJECT	SWA-2026-003	Project	f	Reformer Hot Insulation	DBR	Revit	Manual	5.00	5.00	DBR initial draft	2026-06-27 11:53:55.284358+05:30	2026-06-27 11:53:55.284358+05:30
fb531321-06e7-4a42-8469-33fc4a2ceaed	2026-06-23	8e0c17cd-5487-416f-b795-caaf6d8e8a13	PM	PRE-PROJECT	SWA-INQ-001	Token	f	Boiler Insulation Retrofit	REV	Word	Manual	2.00	0.00	Non-billable review	2026-06-27 11:53:55.284358+05:30	2026-06-27 11:53:55.284358+05:30
02cdf324-6544-4aba-97c9-ae90f9c8bed8	2026-06-24	604daaee-2407-43c2-a1b2-049b758d661a	AE	PROJECT	SWA-TKN-013	Token	f	Reformer Hot Insulation	CAL	Excel	Manual	3.00	3.00	Material selection calc	2026-06-27 11:53:55.284358+05:30	2026-06-27 11:53:55.284358+05:30
510a5d65-756e-43f1-b3ce-137ead172750	2026-06-25	8e0c17cd-5487-416f-b795-caaf6d8e8a13	PM	INTERNAL	INTERNAL-001	Other	f	Internal — weekly standup	ADMIN	Teams	Manual	1.00	0.00	Weekly team standup	2026-06-27 11:53:55.284358+05:30	2026-06-27 11:53:55.284358+05:30
66ac7049-66ec-48b7-b449-84413b10cd70	2026-06-26	604daaee-2407-43c2-a1b2-049b758d661a	AE	PROJECT	SWA-2026-001	Project	t	Boiler Insulation Retrofit	REV	AutoCAD	Manual	4.00	4.00	R1 revision — auditor feedback	2026-06-27 11:53:55.284358+05:30	2026-06-27 11:53:55.284358+05:30
\.


--
-- Data for Name: timesheet_audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.timesheet_audit_log (id, timesheet_id, action, performed_by, notes, created_at) FROM stdin;
\.


--
-- Data for Name: timesheets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.timesheets (id, user_id, week_start, week_end, status, total_hours, billable_hours, approved_by, approved_at, created_at) FROM stdin;
\.


--
-- Data for Name: tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tokens (id, token_id, token_date, agreement_id, token_type, description, token_status, tokens_used, swa_team_lead, project_owner, client_employee_name, client_employee_email, notes, created_at, updated_at) FROM stdin;
bbe9a9e1-d5df-488d-89eb-3609abb6cff7	SWA-TKN-001	2026-06-07	e818cab2-60be-45d1-9bf0-f010c641c2bd	Query	Boiler insulation material query	In Progress	0.50	\N	\N	Amit Kumar	\N	\N	2026-06-27 11:53:55.284358+05:30	2026-06-27 11:53:55.284358+05:30
6e564609-b4d7-4912-814f-5bc291a35a39	SWA-TKN-002	2026-06-07	e818cab2-60be-45d1-9bf0-f010c641c2bd	Design	Thermal design — Unit 4 boiler	In Progress	1.00	\N	\N	Amit Kumar	\N	\N	2026-06-27 11:53:55.284358+05:30	2026-06-27 11:53:55.284358+05:30
730eef8f-4180-4f4e-8082-64dc1d2946d8	SWA-TKN-003	2026-06-07	e818cab2-60be-45d1-9bf0-f010c641c2bd	Calculation	Heat loss calculation sheet	Closed	1.00	\N	\N	Amit Kumar	\N	\N	2026-06-27 11:53:55.284358+05:30	2026-06-27 11:53:55.284358+05:30
ac0f5051-ab8a-46b5-bbaa-20c34418df4f	SWA-TKN-004	2026-06-07	e818cab2-60be-45d1-9bf0-f010c641c2bd	Report	Insulation survey report draft	In Progress	0.50	\N	\N	Amit Kumar	\N	\N	2026-06-27 11:53:55.284358+05:30	2026-06-27 11:53:55.284358+05:30
702681bd-1d53-4836-bab0-57c1749d179b	SWA-TKN-005	2026-06-07	e818cab2-60be-45d1-9bf0-f010c641c2bd	Review	Material spec review — IS standards	In Progress	1.00	\N	\N	Amit Kumar	\N	\N	2026-06-27 11:53:55.284358+05:30	2026-06-27 11:53:55.284358+05:30
6e6e6663-031a-4e1f-9845-747616d70732	SWA-TKN-006	2026-06-07	e818cab2-60be-45d1-9bf0-f010c641c2bd	Design	Vendor coordination drawings	In Progress	2.00	\N	\N	Amit Kumar	\N	\N	2026-06-27 11:53:55.284358+05:30	2026-06-27 11:53:55.284358+05:30
57c321de-e6c4-4681-a2d6-e6675e25198f	SWA-TKN-007	2026-06-07	3eec4ded-d7fb-43d2-9b56-6a4dbf1db440	Query	Pre-audit site data collection	In Progress	0.50	\N	\N	Amit Kumar	\N	\N	2026-06-27 11:53:55.284358+05:30	2026-06-27 11:53:55.284358+05:30
0326fcc6-dfa4-4e76-ac54-dd0e300d997c	SWA-TKN-008	2026-06-07	3eec4ded-d7fb-43d2-9b56-6a4dbf1db440	Calculation	Energy balance calculation	In Progress	1.00	\N	\N	Amit Kumar	\N	\N	2026-06-27 11:53:55.284358+05:30	2026-06-27 11:53:55.284358+05:30
e6acfab2-1f4c-4736-bb36-f7bbd347ff8e	SWA-TKN-009	2026-06-07	3eec4ded-d7fb-43d2-9b56-6a4dbf1db440	Report	Insulation efficiency report	In Progress	1.00	\N	\N	Amit Kumar	\N	\N	2026-06-27 11:53:55.284358+05:30	2026-06-27 11:53:55.284358+05:30
767716ec-8495-48a7-9595-7fcd7be011f9	SWA-TKN-010	2026-06-07	3eec4ded-d7fb-43d2-9b56-6a4dbf1db440	Design	Retrofit recommendation report	In Progress	1.00	\N	\N	Amit Kumar	\N	\N	2026-06-27 11:53:55.284358+05:30	2026-06-27 11:53:55.284358+05:30
734120e3-0fc3-48d0-910f-ca93a9b5494c	SWA-TKN-011	2026-06-07	3eec4ded-d7fb-43d2-9b56-6a4dbf1db440	Review	Draft review — auditor feedback	In Progress	0.50	\N	\N	Amit Kumar	\N	\N	2026-06-27 11:53:55.284358+05:30	2026-06-27 11:53:55.284358+05:30
45f2284a-66b9-4958-83ac-585fc300c33b	SWA-TKN-012	2026-06-07	67285f9b-cf72-4abb-9b65-6e88bc31ed16	Query	Process piping temperature data	In Progress	0.50	\N	\N	Amit Kumar	\N	\N	2026-06-27 11:53:55.284358+05:30	2026-06-27 11:53:55.284358+05:30
ba513fd2-d36c-4ef3-bb63-8ecf4de4ff19	SWA-TKN-013	2026-06-07	67285f9b-cf72-4abb-9b65-6e88bc31ed16	Design	Reformer insulation material spec	In Progress	1.50	\N	\N	Amit Kumar	\N	\N	2026-06-27 11:53:55.284358+05:30	2026-06-27 11:53:55.284358+05:30
822c2d34-ccf5-4373-bc75-c861f531cc02	SWA-TKN-014	2026-06-07	67285f9b-cf72-4abb-9b65-6e88bc31ed16	Calculation	Heat loss modelling — high temp	In Progress	1.00	\N	\N	Amit Kumar	\N	\N	2026-06-27 11:53:55.284358+05:30	2026-06-27 11:53:55.284358+05:30
b29cb2df-a805-4c57-85b0-779f6f155466	SWA-TKN-015	2026-06-07	67285f9b-cf72-4abb-9b65-6e88bc31ed16	Report	Final consultation report	In Progress	2.00	\N	\N	Amit Kumar	\N	\N	2026-06-27 11:53:55.284358+05:30	2026-06-27 11:53:55.284358+05:30
\.


--
-- Data for Name: units_of_measure; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.units_of_measure (id, name, abbreviation) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, email, password_hash, name, role, is_active, created_at, updated_at, deleted_at, version, employee_business_id, employee_role_code, department, date_of_joining, date_of_exit, employment_status, location, reporting_manager_id) FROM stdin;
604daaee-2407-43c2-a1b2-049b758d661a	admin@swa.co.in	$2b$12$blKFhdeXPvA1DzUyzLEQxuQTUU2uqpl2ROkRxmIgqeoHKOUV14pQ.	Admin	admin	t	2026-05-19 23:53:44.076051+05:30	2026-05-19 23:53:44.076051+05:30	\N	1	\N	\N	\N	\N	\N	Active	\N	\N
8e0c17cd-5487-416f-b795-caaf6d8e8a13	pm@swa.co.in	$2b$12$EtwnEqb36uF3Ce9mWhX0m.7C2sB.ECKvv4m5kD8KtLYVhR6gejenK	PM	pm	t	2026-05-19 23:53:44.076051+05:30	2026-05-19 23:53:44.076051+05:30	\N	1	\N	\N	\N	\N	\N	Active	\N	\N
b3ccbe51-aa77-48d9-9ee0-d9638f5c38c9	designer@swa.co.in	$2b$12$PNRlhJqdvq04dy1bNam1Ae8mS.YWZYWMMVmL2cCfb1rnuFDFPJOje	Rahul Sharma	designer	t	2026-05-20 16:57:27.26774+05:30	2026-05-20 16:57:27.26774+05:30	\N	1	\N	\N	\N	\N	\N	Active	\N	\N
0a3b4428-bb3c-439b-a1a6-1f9e82f3defa	auditor@swa.co.in	$2b$12$STUMo4B2741zB6prgi.qyO84ZE08EwbPPSeceeseso2jr3Tu1NQly	Ankit Desai	auditor	t	2026-05-20 16:57:27.26774+05:30	2026-05-20 16:57:27.26774+05:30	\N	1	\N	\N	\N	\N	\N	Active	\N	\N
3ba9a171-6f96-4e11-9b35-f5ce4924a1d7	viewer@swa.co.in	$2b$12$1OjDnmqKciaY8B7an8YvgOtYj8T0wddtZN9qkNCGTwrPHf6HPkW92	Neha Gupta	viewer	t	2026-05-20 16:57:27.26774+05:30	2026-05-20 16:57:27.26774+05:30	\N	1	\N	\N	\N	\N	\N	Active	\N	\N
d71bc8d4-5d29-4a29-8174-6dcb4b30218e	admin@swa.local	$2b$12$LO/oLZ193jO1rqPd636UV.LIaAL0vAR.vHmTIvA9QG3vdZ685Ry6G	Admin User	admin	t	2026-05-22 11:38:21.362927+05:30	2026-05-22 11:38:21.362927+05:30	\N	1	\N	\N	\N	\N	\N	Active	\N	\N
45ec38ac-df65-48b8-bab4-fb7c48eca82a	pm@swa.local	$2b$12$rGZGBUHke5KyjSgKFp9xc.TdbyzW/ponXeBMaDpkeEd/gM./Lb4Hq	PM User	pm	t	2026-05-22 11:38:21.362927+05:30	2026-05-22 11:38:21.362927+05:30	\N	1	\N	\N	\N	\N	\N	Active	\N	\N
\.


--
-- Data for Name: vendor_contacts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vendor_contacts (id, vendor_id, name, designation, email, phone, is_primary) FROM stdin;
\.


--
-- Data for Name: vendor_material_prices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vendor_material_prices (id, vendor_id, material_id, price, moq, lead_time_days, valid_until, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: vendors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vendors (id, name, code, address, city, state, pincode, country, gst_number, primary_email, primary_phone, rating, notes, is_active, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: website_metrics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.website_metrics (id, metric_id, period_yyyymm, sessions, users, new_users, returning_users, page_views, pages_per_session, avg_session_duration_sec, bounce_rate, direct_traffic_pct, organic_traffic_pct, social_traffic_pct, referral_traffic_pct, paid_traffic_pct, contact_form_submissions, consultation_requests, downloads_count, call_clicks, leads_count, inquiry_count, projects_converted, notes, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Name: audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_log_id_seq', 93, true);


--
-- Name: material_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.material_categories_id_seq', 1, false);


--
-- Name: units_of_measure_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.units_of_measure_id_seq', 1, false);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: boq_items boq_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.boq_items
    ADD CONSTRAINT boq_items_pkey PRIMARY KEY (id);


--
-- Name: boqs boqs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.boqs
    ADD CONSTRAINT boqs_pkey PRIMARY KEY (id);


--
-- Name: checklist_items checklist_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.checklist_items
    ADD CONSTRAINT checklist_items_pkey PRIMARY KEY (id);


--
-- Name: client_complaints client_complaints_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_complaints
    ADD CONSTRAINT client_complaints_pkey PRIMARY KEY (id);


--
-- Name: client_feedbacks client_feedbacks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_feedbacks
    ADD CONSTRAINT client_feedbacks_pkey PRIMARY KEY (id);


--
-- Name: clients clients_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_code_key UNIQUE (code);


--
-- Name: clients clients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_pkey PRIMARY KEY (id);


--
-- Name: compliance_checklist_items compliance_checklist_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compliance_checklist_items
    ADD CONSTRAINT compliance_checklist_items_pkey PRIMARY KEY (id);


--
-- Name: compliance_checklists compliance_checklists_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compliance_checklists
    ADD CONSTRAINT compliance_checklists_pkey PRIMARY KEY (id);


--
-- Name: compliance_standards compliance_standards_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compliance_standards
    ADD CONSTRAINT compliance_standards_name_key UNIQUE (name);


--
-- Name: compliance_standards compliance_standards_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compliance_standards
    ADD CONSTRAINT compliance_standards_pkey PRIMARY KEY (id);


--
-- Name: compliance_templates compliance_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compliance_templates
    ADD CONSTRAINT compliance_templates_pkey PRIMARY KEY (id);


--
-- Name: contacts contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_pkey PRIMARY KEY (id);


--
-- Name: document_folders document_folders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_folders
    ADD CONSTRAINT document_folders_pkey PRIMARY KEY (id);


--
-- Name: document_references document_references_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_references
    ADD CONSTRAINT document_references_pkey PRIMARY KEY (id);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: drn drn_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.drn
    ADD CONSTRAINT drn_pkey PRIMARY KEY (id);


--
-- Name: inquiries inquiries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inquiries
    ADD CONSTRAINT inquiries_pkey PRIMARY KEY (id);


--
-- Name: instagram_metrics instagram_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.instagram_metrics
    ADD CONSTRAINT instagram_metrics_pkey PRIMARY KEY (id);


--
-- Name: invoice_items invoice_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_items
    ADD CONSTRAINT invoice_items_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: linkedin_metrics linkedin_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.linkedin_metrics
    ADD CONSTRAINT linkedin_metrics_pkey PRIMARY KEY (id);


--
-- Name: material_categories material_categories_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.material_categories
    ADD CONSTRAINT material_categories_name_key UNIQUE (name);


--
-- Name: material_categories material_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.material_categories
    ADD CONSTRAINT material_categories_pkey PRIMARY KEY (id);


--
-- Name: materials materials_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.materials
    ADD CONSTRAINT materials_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: id_sequence pk_id_sequence; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.id_sequence
    ADD CONSTRAINT pk_id_sequence PRIMARY KEY (type_code, year);


--
-- Name: project_compliance_items project_compliance_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_compliance_items
    ADD CONSTRAINT project_compliance_items_pkey PRIMARY KEY (id);


--
-- Name: project_costs project_costs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_costs
    ADD CONSTRAINT project_costs_pkey PRIMARY KEY (id);


--
-- Name: projects projects_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_code_key UNIQUE (code);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: quote_items quote_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quote_items
    ADD CONSTRAINT quote_items_pkey PRIMARY KEY (id);


--
-- Name: quotes quotes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotes
    ADD CONSTRAINT quotes_pkey PRIMARY KEY (id);


--
-- Name: reference_counters reference_counters_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reference_counters
    ADD CONSTRAINT reference_counters_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: research_collaborations research_collaborations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.research_collaborations
    ADD CONSTRAINT research_collaborations_pkey PRIMARY KEY (id);


--
-- Name: research_innovations research_innovations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.research_innovations
    ADD CONSTRAINT research_innovations_pkey PRIMARY KEY (id);


--
-- Name: rfq_items rfq_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rfq_items
    ADD CONSTRAINT rfq_items_pkey PRIMARY KEY (id);


--
-- Name: rfq_responses rfq_responses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rfq_responses
    ADD CONSTRAINT rfq_responses_pkey PRIMARY KEY (id);


--
-- Name: rfqs rfqs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rfqs
    ADD CONSTRAINT rfqs_pkey PRIMARY KEY (id);


--
-- Name: service_agreements service_agreements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_agreements
    ADD CONSTRAINT service_agreements_pkey PRIMARY KEY (id);


--
-- Name: sustainability_metrics sustainability_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sustainability_metrics
    ADD CONSTRAINT sustainability_metrics_pkey PRIMARY KEY (id);


--
-- Name: sustainability_metrics sustainability_metrics_reference_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sustainability_metrics
    ADD CONSTRAINT sustainability_metrics_reference_id_key UNIQUE (reference_id);


--
-- Name: task_comments task_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_comments
    ADD CONSTRAINT task_comments_pkey PRIMARY KEY (id);


--
-- Name: task_dependencies task_dependencies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_dependencies
    ADD CONSTRAINT task_dependencies_pkey PRIMARY KEY (id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: time_entries time_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.time_entries
    ADD CONSTRAINT time_entries_pkey PRIMARY KEY (id);


--
-- Name: time_log time_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.time_log
    ADD CONSTRAINT time_log_pkey PRIMARY KEY (id);


--
-- Name: timesheet_audit_log timesheet_audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.timesheet_audit_log
    ADD CONSTRAINT timesheet_audit_log_pkey PRIMARY KEY (id);


--
-- Name: timesheets timesheets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.timesheets
    ADD CONSTRAINT timesheets_pkey PRIMARY KEY (id);


--
-- Name: tokens tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tokens
    ADD CONSTRAINT tokens_pkey PRIMARY KEY (id);


--
-- Name: tokens tokens_token_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tokens
    ADD CONSTRAINT tokens_token_id_key UNIQUE (token_id);


--
-- Name: project_compliance_items uix_project_checklist; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_compliance_items
    ADD CONSTRAINT uix_project_checklist UNIQUE (project_id, checklist_item_id);


--
-- Name: units_of_measure units_of_measure_abbreviation_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.units_of_measure
    ADD CONSTRAINT units_of_measure_abbreviation_key UNIQUE (abbreviation);


--
-- Name: units_of_measure units_of_measure_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.units_of_measure
    ADD CONSTRAINT units_of_measure_name_key UNIQUE (name);


--
-- Name: units_of_measure units_of_measure_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.units_of_measure
    ADD CONSTRAINT units_of_measure_pkey PRIMARY KEY (id);


--
-- Name: boqs uq_boq_project_version; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.boqs
    ADD CONSTRAINT uq_boq_project_version UNIQUE (project_id, version_number);


--
-- Name: reference_counters uq_refcounter_type_year; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reference_counters
    ADD CONSTRAINT uq_refcounter_type_year UNIQUE (entity_type, year);


--
-- Name: rfq_responses uq_rfq_vendor; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rfq_responses
    ADD CONSTRAINT uq_rfq_vendor UNIQUE (rfq_id, vendor_id);


--
-- Name: task_dependencies uq_task_dependency; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_dependencies
    ADD CONSTRAINT uq_task_dependency UNIQUE (task_id, depends_on_task_id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: vendor_contacts vendor_contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendor_contacts
    ADD CONSTRAINT vendor_contacts_pkey PRIMARY KEY (id);


--
-- Name: vendor_material_prices vendor_material_prices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendor_material_prices
    ADD CONSTRAINT vendor_material_prices_pkey PRIMARY KEY (id);


--
-- Name: vendors vendors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendors
    ADD CONSTRAINT vendors_pkey PRIMARY KEY (id);


--
-- Name: website_metrics website_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.website_metrics
    ADD CONSTRAINT website_metrics_pkey PRIMARY KEY (id);


--
-- Name: ix_audit_log_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_log_created_at ON public.audit_log USING btree (created_at);


--
-- Name: ix_audit_log_entity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_log_entity ON public.audit_log USING btree (entity_type, entity_id);


--
-- Name: ix_boq_items_boq_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_boq_items_boq_id ON public.boq_items USING btree (boq_id);


--
-- Name: ix_boqs_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_boqs_project_id ON public.boqs USING btree (project_id);


--
-- Name: ix_checklist_items_checklist_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_checklist_items_checklist_id ON public.checklist_items USING btree (checklist_id);


--
-- Name: ix_client_complaints_client_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_client_complaints_client_id ON public.client_complaints USING btree (client_id);


--
-- Name: ix_client_complaints_complaint_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_client_complaints_complaint_id ON public.client_complaints USING btree (complaint_id);


--
-- Name: ix_client_feedbacks_client_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_client_feedbacks_client_id ON public.client_feedbacks USING btree (client_id);


--
-- Name: ix_client_feedbacks_feedback_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_client_feedbacks_feedback_id ON public.client_feedbacks USING btree (feedback_id);


--
-- Name: ix_clients_code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_clients_code ON public.clients USING btree (code);


--
-- Name: ix_compliance_checklist_items_standard_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_compliance_checklist_items_standard_id ON public.compliance_checklist_items USING btree (standard_id);


--
-- Name: ix_compliance_checklists_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_compliance_checklists_project_id ON public.compliance_checklists USING btree (project_id);


--
-- Name: ix_compliance_checklists_template_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_compliance_checklists_template_id ON public.compliance_checklists USING btree (template_id);


--
-- Name: ix_compliance_templates_standard_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_compliance_templates_standard_code ON public.compliance_templates USING btree (standard_code);


--
-- Name: ix_contacts_client_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_contacts_client_id ON public.contacts USING btree (client_id);


--
-- Name: ix_document_folders_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_folders_project_id ON public.document_folders USING btree (project_id);


--
-- Name: ix_document_references_drn; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_document_references_drn ON public.document_references USING btree (drn);


--
-- Name: ix_document_references_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_references_project_id ON public.document_references USING btree (project_id);


--
-- Name: ix_document_references_token_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_references_token_id ON public.document_references USING btree (token_id);


--
-- Name: ix_documents_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_documents_project_id ON public.documents USING btree (project_id);


--
-- Name: ix_drn_associated_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_drn_associated_project_id ON public.drn USING btree (associated_project_id);


--
-- Name: ix_drn_associated_token_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_drn_associated_token_id ON public.drn USING btree (associated_token_id);


--
-- Name: ix_drn_author_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_drn_author_id ON public.drn USING btree (author_id);


--
-- Name: ix_drn_drn_code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_drn_drn_code ON public.drn USING btree (drn_code);


--
-- Name: ix_inquiries_inquiry_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_inquiries_inquiry_id ON public.inquiries USING btree (inquiry_id);


--
-- Name: ix_instagram_metrics_metric_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_instagram_metrics_metric_id ON public.instagram_metrics USING btree (metric_id);


--
-- Name: ix_instagram_metrics_period_yyyymm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_instagram_metrics_period_yyyymm ON public.instagram_metrics USING btree (period_yyyymm);


--
-- Name: ix_invoice_items_invoice_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_invoice_items_invoice_id ON public.invoice_items USING btree (invoice_id);


--
-- Name: ix_invoices_invoice_number; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_invoices_invoice_number ON public.invoices USING btree (invoice_number);


--
-- Name: ix_invoices_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_invoices_project_id ON public.invoices USING btree (project_id);


--
-- Name: ix_linkedin_metrics_metric_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_linkedin_metrics_metric_id ON public.linkedin_metrics USING btree (metric_id);


--
-- Name: ix_linkedin_metrics_period_yyyymm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_linkedin_metrics_period_yyyymm ON public.linkedin_metrics USING btree (period_yyyymm);


--
-- Name: ix_materials_code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_materials_code ON public.materials USING btree (code);


--
-- Name: ix_notifications_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_notifications_created_at ON public.notifications USING btree (created_at);


--
-- Name: ix_notifications_is_read; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_notifications_is_read ON public.notifications USING btree (is_read);


--
-- Name: ix_notifications_reference_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_notifications_reference_id ON public.notifications USING btree (reference_id);


--
-- Name: ix_notifications_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_notifications_type ON public.notifications USING btree (type);


--
-- Name: ix_notifications_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_notifications_user_id ON public.notifications USING btree (user_id);


--
-- Name: ix_project_compliance_items_checklist_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_project_compliance_items_checklist_item_id ON public.project_compliance_items USING btree (checklist_item_id);


--
-- Name: ix_project_compliance_items_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_project_compliance_items_project_id ON public.project_compliance_items USING btree (project_id);


--
-- Name: ix_project_costs_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_project_costs_project_id ON public.project_costs USING btree (project_id);


--
-- Name: ix_projects_business_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_projects_business_id ON public.projects USING btree (business_id);


--
-- Name: ix_projects_client_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_projects_client_id ON public.projects USING btree (client_id);


--
-- Name: ix_projects_code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_projects_code ON public.projects USING btree (code);


--
-- Name: ix_projects_milestone; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_projects_milestone ON public.projects USING btree (milestone);


--
-- Name: ix_projects_pm_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_projects_pm_id ON public.projects USING btree (pm_id);


--
-- Name: ix_projects_project_owner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_projects_project_owner_id ON public.projects USING btree (project_owner_id);


--
-- Name: ix_projects_team_leader_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_projects_team_leader_id ON public.projects USING btree (team_leader_id);


--
-- Name: ix_quote_items_quote_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_quote_items_quote_id ON public.quote_items USING btree (quote_id);


--
-- Name: ix_quotes_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_quotes_project_id ON public.quotes USING btree (project_id);


--
-- Name: ix_refresh_tokens_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_refresh_tokens_user_id ON public.refresh_tokens USING btree (user_id);


--
-- Name: ix_research_collaborations_collab_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_research_collaborations_collab_id ON public.research_collaborations USING btree (collab_id);


--
-- Name: ix_research_innovations_innovation_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_research_innovations_innovation_id ON public.research_innovations USING btree (innovation_id);


--
-- Name: ix_rfq_items_boq_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_rfq_items_boq_item_id ON public.rfq_items USING btree (boq_item_id);


--
-- Name: ix_rfq_items_material_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_rfq_items_material_id ON public.rfq_items USING btree (material_id);


--
-- Name: ix_rfq_items_rfq_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_rfq_items_rfq_id ON public.rfq_items USING btree (rfq_id);


--
-- Name: ix_rfq_responses_rfq_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_rfq_responses_rfq_id ON public.rfq_responses USING btree (rfq_id);


--
-- Name: ix_rfq_responses_vendor_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_rfq_responses_vendor_id ON public.rfq_responses USING btree (vendor_id);


--
-- Name: ix_rfqs_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_rfqs_project_id ON public.rfqs USING btree (project_id);


--
-- Name: ix_rfqs_quote_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_rfqs_quote_id ON public.rfqs USING btree (quote_id);


--
-- Name: ix_service_agreements_agreement_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_service_agreements_agreement_id ON public.service_agreements USING btree (agreement_id);


--
-- Name: ix_service_agreements_client_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_service_agreements_client_id ON public.service_agreements USING btree (client_id);


--
-- Name: ix_service_agreements_inquiry_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_service_agreements_inquiry_id ON public.service_agreements USING btree (inquiry_id);


--
-- Name: ix_sustainability_metrics_measured_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_sustainability_metrics_measured_at ON public.sustainability_metrics USING btree (measured_at);


--
-- Name: ix_sustainability_metrics_reference_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_sustainability_metrics_reference_id ON public.sustainability_metrics USING btree (reference_id);


--
-- Name: ix_sustainability_metrics_reference_kind; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_sustainability_metrics_reference_kind ON public.sustainability_metrics USING btree (reference_kind);


--
-- Name: ix_task_comments_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_task_comments_task_id ON public.task_comments USING btree (task_id);


--
-- Name: ix_task_dependencies_depends_on_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_task_dependencies_depends_on_task_id ON public.task_dependencies USING btree (depends_on_task_id);


--
-- Name: ix_task_dependencies_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_task_dependencies_task_id ON public.task_dependencies USING btree (task_id);


--
-- Name: ix_tasks_assignee_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_tasks_assignee_id ON public.tasks USING btree (assignee_id);


--
-- Name: ix_tasks_parent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_tasks_parent_id ON public.tasks USING btree (parent_id);


--
-- Name: ix_tasks_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_tasks_project_id ON public.tasks USING btree (project_id);


--
-- Name: ix_time_entries_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_time_entries_project_id ON public.time_entries USING btree (project_id);


--
-- Name: ix_time_entries_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_time_entries_task_id ON public.time_entries USING btree (task_id);


--
-- Name: ix_time_entries_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_time_entries_user_id ON public.time_entries USING btree (user_id);


--
-- Name: ix_time_log_employee_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_time_log_employee_id ON public.time_log USING btree (employee_id);


--
-- Name: ix_timesheet_audit_log_timesheet_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_timesheet_audit_log_timesheet_id ON public.timesheet_audit_log USING btree (timesheet_id);


--
-- Name: ix_timesheets_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_timesheets_user_id ON public.timesheets USING btree (user_id);


--
-- Name: ix_tokens_agreement_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_tokens_agreement_date ON public.tokens USING btree (agreement_id, token_date);


--
-- Name: ix_tokens_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_tokens_status ON public.tokens USING btree (token_status);


--
-- Name: ix_tokens_token_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_tokens_token_id ON public.tokens USING btree (token_id);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_vendor_contacts_vendor_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_vendor_contacts_vendor_id ON public.vendor_contacts USING btree (vendor_id);


--
-- Name: ix_vendor_material_prices_material_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_vendor_material_prices_material_id ON public.vendor_material_prices USING btree (material_id);


--
-- Name: ix_vendor_material_prices_vendor_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_vendor_material_prices_vendor_id ON public.vendor_material_prices USING btree (vendor_id);


--
-- Name: ix_vendors_code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_vendors_code ON public.vendors USING btree (code);


--
-- Name: ix_website_metrics_metric_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_website_metrics_metric_id ON public.website_metrics USING btree (metric_id);


--
-- Name: ix_website_metrics_period_yyyymm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_website_metrics_period_yyyymm ON public.website_metrics USING btree (period_yyyymm);


--
-- Name: boq_items boq_items_boq_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.boq_items
    ADD CONSTRAINT boq_items_boq_id_fkey FOREIGN KEY (boq_id) REFERENCES public.boqs(id);


--
-- Name: boqs boqs_parsed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.boqs
    ADD CONSTRAINT boqs_parsed_by_fkey FOREIGN KEY (parsed_by) REFERENCES public.users(id);


--
-- Name: boqs boqs_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.boqs
    ADD CONSTRAINT boqs_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: checklist_items checklist_items_checklist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.checklist_items
    ADD CONSTRAINT checklist_items_checklist_id_fkey FOREIGN KEY (checklist_id) REFERENCES public.compliance_checklists(id);


--
-- Name: checklist_items checklist_items_completed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.checklist_items
    ADD CONSTRAINT checklist_items_completed_by_fkey FOREIGN KEY (completed_by) REFERENCES public.users(id);


--
-- Name: checklist_items checklist_items_evidence_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.checklist_items
    ADD CONSTRAINT checklist_items_evidence_document_id_fkey FOREIGN KEY (evidence_document_id) REFERENCES public.documents(id);


--
-- Name: client_complaints client_complaints_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_complaints
    ADD CONSTRAINT client_complaints_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id);


--
-- Name: client_complaints client_complaints_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_complaints
    ADD CONSTRAINT client_complaints_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id);


--
-- Name: client_feedbacks client_feedbacks_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.client_feedbacks
    ADD CONSTRAINT client_feedbacks_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id);


--
-- Name: compliance_checklist_items compliance_checklist_items_standard_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compliance_checklist_items
    ADD CONSTRAINT compliance_checklist_items_standard_id_fkey FOREIGN KEY (standard_id) REFERENCES public.compliance_standards(id);


--
-- Name: compliance_checklists compliance_checklists_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compliance_checklists
    ADD CONSTRAINT compliance_checklists_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: compliance_checklists compliance_checklists_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compliance_checklists
    ADD CONSTRAINT compliance_checklists_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.compliance_templates(id);


--
-- Name: contacts contacts_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: document_folders document_folders_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_folders
    ADD CONSTRAINT document_folders_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.document_folders(id);


--
-- Name: document_folders document_folders_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_folders
    ADD CONSTRAINT document_folders_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: document_references document_references_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_references
    ADD CONSTRAINT document_references_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: document_references document_references_token_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_references
    ADD CONSTRAINT document_references_token_id_fkey FOREIGN KEY (token_id) REFERENCES public.tokens(id);


--
-- Name: documents documents_previous_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_previous_version_id_fkey FOREIGN KEY (previous_version_id) REFERENCES public.documents(id);


--
-- Name: documents documents_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: documents documents_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.users(id);


--
-- Name: drn drn_associated_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.drn
    ADD CONSTRAINT drn_associated_project_id_fkey FOREIGN KEY (associated_project_id) REFERENCES public.projects(id);


--
-- Name: drn drn_associated_token_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.drn
    ADD CONSTRAINT drn_associated_token_id_fkey FOREIGN KEY (associated_token_id) REFERENCES public.tokens(id);


--
-- Name: drn drn_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.drn
    ADD CONSTRAINT drn_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id);


--
-- Name: inquiries fk_inquiries_converted_to_agreement_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inquiries
    ADD CONSTRAINT fk_inquiries_converted_to_agreement_id FOREIGN KEY (converted_to_agreement_id) REFERENCES public.service_agreements(id) ON DELETE SET NULL;


--
-- Name: projects fk_projects_project_owner_id_users; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT fk_projects_project_owner_id_users FOREIGN KEY (project_owner_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: projects fk_projects_team_leader_id_users; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT fk_projects_team_leader_id_users FOREIGN KEY (team_leader_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: inquiries inquiries_converted_to_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inquiries
    ADD CONSTRAINT inquiries_converted_to_client_id_fkey FOREIGN KEY (converted_to_client_id) REFERENCES public.clients(id);


--
-- Name: inquiries inquiries_owner_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inquiries
    ADD CONSTRAINT inquiries_owner_fkey FOREIGN KEY (owner) REFERENCES public.users(id);


--
-- Name: inquiries inquiries_technical_lead_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inquiries
    ADD CONSTRAINT inquiries_technical_lead_fkey FOREIGN KEY (technical_lead) REFERENCES public.users(id);


--
-- Name: invoice_items invoice_items_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_items
    ADD CONSTRAINT invoice_items_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoices(id);


--
-- Name: invoices invoices_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: invoices invoices_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: materials materials_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.materials
    ADD CONSTRAINT materials_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.material_categories(id);


--
-- Name: materials materials_unit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.materials
    ADD CONSTRAINT materials_unit_id_fkey FOREIGN KEY (unit_id) REFERENCES public.units_of_measure(id);


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: project_compliance_items project_compliance_items_checklist_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_compliance_items
    ADD CONSTRAINT project_compliance_items_checklist_item_id_fkey FOREIGN KEY (checklist_item_id) REFERENCES public.compliance_checklist_items(id);


--
-- Name: project_compliance_items project_compliance_items_evidence_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_compliance_items
    ADD CONSTRAINT project_compliance_items_evidence_document_id_fkey FOREIGN KEY (evidence_document_id) REFERENCES public.documents(id);


--
-- Name: project_compliance_items project_compliance_items_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_compliance_items
    ADD CONSTRAINT project_compliance_items_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: project_compliance_items project_compliance_items_reviewed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_compliance_items
    ADD CONSTRAINT project_compliance_items_reviewed_by_fkey FOREIGN KEY (reviewed_by) REFERENCES public.users(id);


--
-- Name: project_costs project_costs_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_costs
    ADD CONSTRAINT project_costs_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: project_costs project_costs_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_costs
    ADD CONSTRAINT project_costs_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: projects projects_auditor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_auditor_id_fkey FOREIGN KEY (auditor_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: projects projects_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: projects projects_designer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_designer_id_fkey FOREIGN KEY (designer_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: projects projects_pm_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pm_id_fkey FOREIGN KEY (pm_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: quote_items quote_items_boq_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quote_items
    ADD CONSTRAINT quote_items_boq_item_id_fkey FOREIGN KEY (boq_item_id) REFERENCES public.boq_items(id);


--
-- Name: quote_items quote_items_quote_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quote_items
    ADD CONSTRAINT quote_items_quote_id_fkey FOREIGN KEY (quote_id) REFERENCES public.quotes(id);


--
-- Name: quotes quotes_approved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotes
    ADD CONSTRAINT quotes_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id);


--
-- Name: quotes quotes_boq_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotes
    ADD CONSTRAINT quotes_boq_id_fkey FOREIGN KEY (boq_id) REFERENCES public.boqs(id);


--
-- Name: quotes quotes_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotes
    ADD CONSTRAINT quotes_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: quotes quotes_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quotes
    ADD CONSTRAINT quotes_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: refresh_tokens refresh_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: research_collaborations research_collaborations_primary_internal_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.research_collaborations
    ADD CONSTRAINT research_collaborations_primary_internal_owner_id_fkey FOREIGN KEY (primary_internal_owner_id) REFERENCES public.users(id);


--
-- Name: research_collaborations research_collaborations_secondary_internal_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.research_collaborations
    ADD CONSTRAINT research_collaborations_secondary_internal_owner_id_fkey FOREIGN KEY (secondary_internal_owner_id) REFERENCES public.users(id);


--
-- Name: research_innovations research_innovations_primary_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.research_innovations
    ADD CONSTRAINT research_innovations_primary_owner_id_fkey FOREIGN KEY (primary_owner_id) REFERENCES public.users(id);


--
-- Name: research_innovations research_innovations_secondary_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.research_innovations
    ADD CONSTRAINT research_innovations_secondary_owner_id_fkey FOREIGN KEY (secondary_owner_id) REFERENCES public.users(id);


--
-- Name: rfq_items rfq_items_boq_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rfq_items
    ADD CONSTRAINT rfq_items_boq_item_id_fkey FOREIGN KEY (boq_item_id) REFERENCES public.boq_items(id);


--
-- Name: rfq_items rfq_items_material_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rfq_items
    ADD CONSTRAINT rfq_items_material_id_fkey FOREIGN KEY (material_id) REFERENCES public.materials(id);


--
-- Name: rfq_items rfq_items_rfq_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rfq_items
    ADD CONSTRAINT rfq_items_rfq_id_fkey FOREIGN KEY (rfq_id) REFERENCES public.rfqs(id);


--
-- Name: rfq_responses rfq_responses_rfq_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rfq_responses
    ADD CONSTRAINT rfq_responses_rfq_id_fkey FOREIGN KEY (rfq_id) REFERENCES public.rfqs(id);


--
-- Name: rfq_responses rfq_responses_vendor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rfq_responses
    ADD CONSTRAINT rfq_responses_vendor_id_fkey FOREIGN KEY (vendor_id) REFERENCES public.vendors(id);


--
-- Name: rfqs rfqs_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rfqs
    ADD CONSTRAINT rfqs_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: rfqs rfqs_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rfqs
    ADD CONSTRAINT rfqs_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: rfqs rfqs_quote_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rfqs
    ADD CONSTRAINT rfqs_quote_id_fkey FOREIGN KEY (quote_id) REFERENCES public.quotes(id);


--
-- Name: service_agreements service_agreements_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_agreements
    ADD CONSTRAINT service_agreements_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id);


--
-- Name: service_agreements service_agreements_inquiry_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_agreements
    ADD CONSTRAINT service_agreements_inquiry_id_fkey FOREIGN KEY (inquiry_id) REFERENCES public.inquiries(id) ON DELETE SET NULL;


--
-- Name: task_comments task_comments_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_comments
    ADD CONSTRAINT task_comments_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: task_comments task_comments_parent_comment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_comments
    ADD CONSTRAINT task_comments_parent_comment_id_fkey FOREIGN KEY (parent_comment_id) REFERENCES public.task_comments(id) ON DELETE CASCADE;


--
-- Name: task_comments task_comments_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_comments
    ADD CONSTRAINT task_comments_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: task_dependencies task_dependencies_depends_on_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_dependencies
    ADD CONSTRAINT task_dependencies_depends_on_task_id_fkey FOREIGN KEY (depends_on_task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: task_dependencies task_dependencies_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_dependencies
    ADD CONSTRAINT task_dependencies_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: tasks tasks_assignee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_assignee_id_fkey FOREIGN KEY (assignee_id) REFERENCES public.users(id);


--
-- Name: tasks tasks_boq_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_boq_item_id_fkey FOREIGN KEY (boq_item_id) REFERENCES public.boq_items(id);


--
-- Name: tasks tasks_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: tasks tasks_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.tasks(id);


--
-- Name: tasks tasks_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: time_entries time_entries_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.time_entries
    ADD CONSTRAINT time_entries_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: time_entries time_entries_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.time_entries
    ADD CONSTRAINT time_entries_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: time_log time_log_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.time_log
    ADD CONSTRAINT time_log_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.users(id);


--
-- Name: timesheet_audit_log timesheet_audit_log_performed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.timesheet_audit_log
    ADD CONSTRAINT timesheet_audit_log_performed_by_fkey FOREIGN KEY (performed_by) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: timesheet_audit_log timesheet_audit_log_timesheet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.timesheet_audit_log
    ADD CONSTRAINT timesheet_audit_log_timesheet_id_fkey FOREIGN KEY (timesheet_id) REFERENCES public.timesheets(id) ON DELETE CASCADE;


--
-- Name: timesheets timesheets_approved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.timesheets
    ADD CONSTRAINT timesheets_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id);


--
-- Name: timesheets timesheets_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.timesheets
    ADD CONSTRAINT timesheets_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: tokens tokens_agreement_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tokens
    ADD CONSTRAINT tokens_agreement_id_fkey FOREIGN KEY (agreement_id) REFERENCES public.service_agreements(id);


--
-- Name: tokens tokens_project_owner_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tokens
    ADD CONSTRAINT tokens_project_owner_fkey FOREIGN KEY (project_owner) REFERENCES public.users(id);


--
-- Name: tokens tokens_swa_team_lead_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tokens
    ADD CONSTRAINT tokens_swa_team_lead_fkey FOREIGN KEY (swa_team_lead) REFERENCES public.users(id);


--
-- Name: vendor_contacts vendor_contacts_vendor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendor_contacts
    ADD CONSTRAINT vendor_contacts_vendor_id_fkey FOREIGN KEY (vendor_id) REFERENCES public.vendors(id) ON DELETE CASCADE;


--
-- Name: vendor_material_prices vendor_material_prices_material_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendor_material_prices
    ADD CONSTRAINT vendor_material_prices_material_id_fkey FOREIGN KEY (material_id) REFERENCES public.materials(id);


--
-- Name: vendor_material_prices vendor_material_prices_vendor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendor_material_prices
    ADD CONSTRAINT vendor_material_prices_vendor_id_fkey FOREIGN KEY (vendor_id) REFERENCES public.vendors(id);


--
-- PostgreSQL database dump complete
--

\unrestrict yvyIUO0ttSvGAyeZLrl5fTYiT69hMoZQQdMknJchktpEPI9NfveESVx9AGQnciE

